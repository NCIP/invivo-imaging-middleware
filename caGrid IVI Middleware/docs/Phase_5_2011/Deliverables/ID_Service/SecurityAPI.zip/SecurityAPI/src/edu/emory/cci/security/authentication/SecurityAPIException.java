package edu.emory.cci.security.authentication;

public class SecurityAPIException extends Exception{

	public SecurityAPIException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SecurityAPIException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public SecurityAPIException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SecurityAPIException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 7135866213941940543L;

}
