package edu.emory.cci.security.authentication;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.globus.gsi.GlobusCredential;

public class RequesterThread  implements Runnable{

	
	private CaBIGSecurityClient caBigSecurityClient;
	private String username;
	private String password;
	StringBuffer response ;
	private Log log = LogFactory.getLog(getClass());
	
	public RequesterThread(CaBIGSecurityClient caBIGSecurityClient,String username,String password,StringBuffer response)
	{
		this.caBigSecurityClient = caBIGSecurityClient;
		this.username = username;
		this.password = password;
		this.response = response;
	}
	
	
	@Override
	public void run() {
		
		GlobusCredential credential = null;
		
		
		try{
			credential = caBigSecurityClient.loginCaBIG(username, password);
			long timeLeft = credential.getTimeLeft() * 1000;
			long expiration = timeLeft + System.currentTimeMillis();
			String sessionId = caBigSecurityClient.generateSessionId();
			caBigSecurityClient.getMapOfSessionIds().put(sessionId, expiration);
			List<String> groups = caBigSecurityClient.getGroupMembershipInfo(credential);
			caBigSecurityClient.getGroupInfo().put(sessionId, groups);
			response.append(caBigSecurityClient.createSuccessResponse(groups, sessionId));
			
		}
		catch(Exception e)
		{
			log.error(e);
			response.append(caBigSecurityClient.createFailureResponse(e.getMessage(), -1));
		}
		finally{
			log.debug("Response set to [" + response + "]");
			
		}
	}


	public StringBuffer getResponse() {
		return response;
	}


	public void setResponse(StringBuffer response) {
		this.response = response;
	}

}
