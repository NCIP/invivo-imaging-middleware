package edu.emory.cci.security.authentication;

public enum SecurityClientType {

	CABIG
}
