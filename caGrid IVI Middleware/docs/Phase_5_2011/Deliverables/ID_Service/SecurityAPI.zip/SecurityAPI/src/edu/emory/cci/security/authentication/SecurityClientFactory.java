package edu.emory.cci.security.authentication;

import java.util.Properties;


public class SecurityClientFactory {

	private Properties props;
	public SecurityClientFactory(Properties props)
	{
		this.props = props;
	}
		
	public  SecurityClient newInstance(SecurityClientType type) throws InstantiationException, IllegalAccessException
	{
		
		switch(type)
		{
			case CABIG: 
				return getCaBIGSecurityClient();
				
			default : throw new InstantiationException("Could not find suitable client for the type :[" + type  + "]");	
		}
	}
	
	private CaBIGSecurityClient getCaBIGSecurityClient() throws InstantiationException
	{
		if(props == null)
			throw new InstantiationException("Could not find properties to configure this instance of SecurityClientFactory. props set to null");
		CaBIGSecurityClient client = new CaBIGSecurityClient();
		if(props.get("CABIG.identityProviderUrl")  == null)
			throw new InstantiationException("The property [CABIG.identityProviderUrl] is null which is required to instantiate the client for type CABIG");
		client.setIdpUrl((String) props.get("CABIG.identityProviderUrl"));
		if(props.get("CABIG.authServiceUrl")  == null)
			throw new InstantiationException("The property [CABIG.authServiceUrl] is null which is required to instantiate the client for type CABIG");
		client.setIfsUrl((String) props.get("CABIG.authServiceUrl"));
		if(props.get("CABIG.gridGrouperUrl")  == null)
			throw new InstantiationException("The property [CABIG.gridGrouperUrl] is null which is required to instantiate the client for type CABIG");
		client.setGridGrouperUrl((String) props.get("CABIG.gridGrouperUrl"));
		
		
//		client.setIdpUrl("https://dorian.training.cagrid.org:8443/wsrf/services/cagrid/Dorian");
//		client.setIfsUrl("https://dorian.training.cagrid.org:8443/wsrf/services/cagrid/Dorian");
//		client.setGridGrouperUrl("https://grouper.training.cagrid.org:8443/wsrf/services/cagrid/GridGrouper");
		client.init();
		return client;
	}

	public Properties getProps() {
		return props;
	}

	public void setProps(Properties props) {
		this.props = props;
	}
	
}
