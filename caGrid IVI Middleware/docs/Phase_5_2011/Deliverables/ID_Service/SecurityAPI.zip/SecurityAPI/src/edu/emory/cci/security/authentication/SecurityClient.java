package edu.emory.cci.security.authentication;

public interface SecurityClient {

	public String login(String usernmae, String password, long timeoutMilliSec) throws SecurityAPIException;
	public String login(String sessionId, long timeoutMilliSec) throws SecurityAPIException;
	
}
