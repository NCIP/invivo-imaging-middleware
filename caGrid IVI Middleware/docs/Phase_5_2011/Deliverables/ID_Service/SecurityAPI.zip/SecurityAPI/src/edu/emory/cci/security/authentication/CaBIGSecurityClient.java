package edu.emory.cci.security.authentication;

import edu.internet2.middleware.grouper.GrouperRuntimeException;
import edu.internet2.middleware.grouper.InsufficientPrivilegeException;
import gov.nih.nci.cagrid.authentication.bean.BasicAuthenticationCredential;
import gov.nih.nci.cagrid.authentication.bean.Credential;
import gov.nih.nci.cagrid.authentication.client.AuthenticationClient;
import gov.nih.nci.cagrid.dorian.client.IFSUserClient;
import gov.nih.nci.cagrid.dorian.ifs.bean.ProxyLifetime;
import gov.nih.nci.cagrid.gridgrouper.client.GridGrouper;
import gov.nih.nci.cagrid.gridgrouper.grouper.GroupI;
import gov.nih.nci.cagrid.opensaml.SAMLAssertion;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bouncycastle.util.encoders.Base64Encoder;
import org.globus.gsi.GlobusCredential;


public class CaBIGSecurityClient implements SecurityClient {

	private Map<String,Long> mapOfSessionIds;
	private Map<String,List<String>> groupInfo;
	private String IdpUrl;
	private String IfsUrl;
	private String gridGrouperUrl;
	private GridGrouper grouper;
	private Log log = LogFactory.getLog(getClass());
	private int certificateLifeTime = 12;
	
	
	public int getCertificateLifeTime() {
		return certificateLifeTime;
	}
	public void setCertificateLifeTime(int certificateLifeTime) {
		this.certificateLifeTime = certificateLifeTime;
	}
	public String getIdpUrl() {
		return IdpUrl;
	}
	public void setIdpUrl(String idpUrl) {
		IdpUrl = idpUrl;
	}
	public String getIfsUrl() {
		return IfsUrl;
	}
	public void setIfsUrl(String ifsUrl) {
		IfsUrl = ifsUrl;
	}
	
	public String getGridGrouperUrl() {
		return gridGrouperUrl;
	}
	public void setGridGrouperUrl(String gridGrouperUrl) {
		this.gridGrouperUrl = gridGrouperUrl;
	}
	public void init(){
		mapOfSessionIds = new HashMap<String, Long>();
		groupInfo = new HashMap<String, List<String>>();
		grouper = new GridGrouper(gridGrouperUrl);
		
	}
	
	
	
	public Map<String, Long> getMapOfSessionIds() {
		return mapOfSessionIds;
	}
	public void setMapOfSessionIds(Map<String, Long> mapOfSessionIds) {
		this.mapOfSessionIds = mapOfSessionIds;
	}
	public Map<String, List<String>> getGroupInfo() {
		return groupInfo;
	}
	public void setGroupInfo(Map<String, List<String>> groupInfo) {
		this.groupInfo = groupInfo;
	}
	public GridGrouper getGrouper() {
		return grouper;
	}
	public void setGrouper(GridGrouper grouper) {
		this.grouper = grouper;
	}
	@Override
	public String login(String username, String password, long timeoutMilliSec) {
		try{
			StringBuffer  response = new StringBuffer();
			
			RequesterThread requesterThread = new RequesterThread(this, username, password , response);
			Thread worker = new Thread(requesterThread);
			worker.start();
			long timeOutOccurs = System.currentTimeMillis() + timeoutMilliSec;
			while(System.currentTimeMillis() < timeOutOccurs)
			{
				synchronized (response) {
					if(response.toString().equals("") !=true)
					{
						
						return response.toString();
					}
				}
				
			}
			
			worker.stop();
			throw new SecurityAPIException("Request Timeout occured");
			
		}catch(Exception e)
		{
			log.error(e);
			return createFailureResponse(e.getMessage(), -1);
		}
		

		
	}
	
	
	public synchronized List<String> getGroupMembershipInfo(GlobusCredential credential ) throws GrouperRuntimeException, InsufficientPrivilegeException
	{
		List<String> list = new ArrayList<String>();
		Set<GroupI> set = grouper.getMembersGroups(credential.getIdentity());
		for(GroupI group : set)
		{
			list.add(group.getName().replaceAll(":", "/"));
		}
		
		return list;
	}
	
	public static String join(Collection<String> s, String delimiter) {
        StringBuffer buffer = new StringBuffer();
        Iterator<String> iter = s.iterator();
        while (iter.hasNext()) {
            buffer.append(iter.next());
            if (iter.hasNext()) {
                buffer.append(delimiter);
            }
        }
        return buffer.toString();
    }
	
	public synchronized String createSuccessResponse(List<String> groupMembership,String sessionId )
	{
		return "PASS \n" +
		"groups:"+ join(groupMembership, ",")+   " \n" +
		"session-id:"+sessionId+"\n";

	}
	
	public synchronized String createFailureResponse(String reason,int code )
	{
		return "FAIL \n" +
		"code:" + code + "\n" +
		"reason:" +  reason ;
	}

	@Override
	public String login(String sessionId, long timeoutMilliSec) throws SecurityAPIException {
		if(mapOfSessionIds.containsKey(sessionId) == false) {
			
			return createFailureResponse("session expired.Please login again", -1);
		}
		long currentTime = System.currentTimeMillis() ;
		long currentExpirationTime = mapOfSessionIds.get(sessionId);
		if(currentTime > currentExpirationTime)
		{
				mapOfSessionIds.remove(sessionId);
				groupInfo.remove(sessionId);
				return createFailureResponse("session expired.Please login again", -1);
			
		}
		else
		{
			return createSuccessResponse(groupInfo.get(sessionId), sessionId);
		}
		
	}
	
	
	public synchronized String generateSessionId() throws NoSuchAlgorithmException
	{
				
		return UUID.randomUUID().toString();
				
	}
	
	 public synchronized GlobusCredential loginCaBIG(String userId, String passwd) throws Exception {
	        Credential credential = new Credential();
	        BasicAuthenticationCredential cred = new BasicAuthenticationCredential();
	        cred.setUserId(userId);
	        cred.setPassword(passwd);
	        credential.setBasicAuthenticationCredential(cred);

	        log.debug("Creating authentication client: URL="+IdpUrl+"; userId=" + userId + "; password="+passwd);
	        AuthenticationClient client = new AuthenticationClient(IdpUrl, credential);
	        log.debug("Authenticating the credentials .....");
	        SAMLAssertion saml = client.authenticate();
	        log.debug("Credentials Authenticated[\n" + saml.toString() );

	        
	        gov.nih.nci.cagrid.dorian.ifs.bean.ProxyLifetime lifetime = new ProxyLifetime();
	        
	        lifetime.setHours(certificateLifeTime);
	        int delegationLifetime = 0;
	        log.debug("Connecting to Dorian to get proxy certificate with lifetime set to [" + certificateLifeTime + "] hrs");
	        IFSUserClient dorian = new IFSUserClient(IfsUrl);
	        log.debug("Creating proxy certificate");
	        GlobusCredential proxy = dorian.createProxy(saml, lifetime, delegationLifetime); 
	        log.debug("Acquired proxy certificate");
	        return proxy;
	    }
	
}
