package edu.emory.cci.authentication.test;

import java.util.Properties;
import java.util.Set;

import junit.framework.TestCase;

import edu.emory.cci.security.authentication.SecurityAPIException;
import edu.emory.cci.security.authentication.SecurityClient;
import edu.emory.cci.security.authentication.SecurityClientFactory;
import edu.emory.cci.security.authentication.SecurityClientType;
import edu.internet2.middleware.grouper.GrouperRuntimeException;
import edu.internet2.middleware.grouper.InsufficientPrivilegeException;
import gov.nih.nci.cagrid.gridgrouper.client.GridGrouper;
import gov.nih.nci.cagrid.gridgrouper.grouper.GroupI;

public class TestCaBIGSecurityClient extends TestCase{

	private SecurityClient client;
	@Override
	protected void setUp() throws Exception {
				super.setUp();
				Properties props = new Properties();
				props.setProperty("CABIG.identityProviderUrl", "https://dorian.training.cagrid.org:8443/wsrf/services/cagrid/Dorian");
				props.setProperty("CABIG.authServiceUrl", "https://dorian.training.cagrid.org:8443/wsrf/services/cagrid/Dorian");
				props.setProperty("CABIG.gridGrouperUrl", "https://grouper.training.cagrid.org:8443/wsrf/services/cagrid/GridGrouper");
				SecurityClientFactory factory = new SecurityClientFactory(props);
				client = factory.newInstance(SecurityClientType.CABIG);
	}
	
	public void testLoginFirstTime() 
	{
		
		try {
			String message = client.login("bogus1", "pswd123456X$", 100000);
			System.out.println("testLoginFirstTime:\n" + message);
			assertTrue(message.contains("PASS") == true);
		} catch (SecurityAPIException e) {
			fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void testRelogin()
	{

		try {
			String message = client.login("bogus1", "pswd123456X$", 100000);
			String[] st = message.split("\n");
			String sessionId = st[2].replace("session-id:", "");
			
			message = client.login(sessionId, 3000);
			System.out.println("testRelogin:\n" + message);
			assertTrue(message.contains("PASS") == true);
		} catch (SecurityAPIException e) {
			fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void testTimeout()
	{
		try {
			String message = client.login("bogus1", "pswd123456X$", 1000);
			System.out.println(message);
			assertTrue(message.contains("FAIL") == true);
		} catch (SecurityAPIException e) {
			fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public void testGridGrouper() throws GrouperRuntimeException, InsufficientPrivilegeException
	{
		GridGrouper grouper = new GridGrouper("https://grouper.training.cagrid.org:8443/wsrf/services/cagrid/GridGrouper");
		Set<GroupI> set = grouper.getMembersGroups("/O=caBIG/OU=caGrid/OU=Training/OU=Dorian/CN=bogus1");
		System.out.println(set);
	}
}
