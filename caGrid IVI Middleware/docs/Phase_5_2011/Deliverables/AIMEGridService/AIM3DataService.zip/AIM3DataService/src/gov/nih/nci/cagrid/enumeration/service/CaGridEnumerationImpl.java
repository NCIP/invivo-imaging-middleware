package gov.nih.nci.cagrid.enumeration.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class CaGridEnumerationImpl extends CaGridEnumerationImplBase {

	
	public CaGridEnumerationImpl() throws RemoteException {
		super();
	}
	
}

