package edu.emory.cci.aim.client;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

import edu.emory.cci.utils.xml.StringTransform;
import edu.emory.cci.utils.xml.TransformException;

public class AIMDocPreprocessor implements StringTransform {

//	private	XMLEventFactory eventFactory;
//	private XMLOutputFactory outputfactory;
//	private XMLInputFactory inputfactory;

	
	public AIMDocPreprocessor() {
		super();
//		eventFactory = XMLEventFactory.newInstance();
//		inputfactory = XMLInputFactory.newInstance();
//		outputfactory = XMLOutputFactory.newInstance();
	}

	private static final String ZERO_ID = " id=\"0\"";
	private static final String EMPTY_ID = " id=\"\"";

	public String transform(String arg0) throws TransformException {
		String output = this.transform(arg0, EMPTY_ID);
		output = this.transform(arg0, ZERO_ID);
		return output;
	}

	public InputStream transform(InputStream arg0) throws TransformException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		byte[] data = new byte[8192];
		int read = 0;
		try {
			while ((read = arg0.read(data, 0, 8192)) != -1) {
				baos.write(data, 0, read);
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new TransformException("error reading the input stream: " + e.getMessage(), e);
		}
		String xml = new String(baos.toByteArray(), 0, baos.size());
		
		String newxml = this.transform(xml);
		return new ByteArrayInputStream(newxml.getBytes());
		
//		// set up the piped streams
//		PipedOutputStream pos = new PipedOutputStream();
//		PipedInputStream pis = new PipedInputStream();
//		try {
//			pos.connect(pis);
//		} catch (IOException e) {
//			throw new TransformException("Unable to make a pipe", e);
//		}
//
//	    XMLEventReader reader = null;
//		try {
//			reader = inputfactory.createXMLEventReader(arg0);
//		} catch (XMLStreamException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		if (reader == null) return null;
//		XMLEventWriter writer = null;
//		try {
//			writer = outputfactory.createXMLEventWriter(new BufferedOutputStream(pos));
//		} catch (XMLStreamException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		if (writer == null) return null;
//
//		
//		// The part below needs to be threaded, since the transfer service creation reads from the stream completely.
//		final PipedOutputStream fpos = pos;
//		final XMLEventReader freader = reader;
//		final XMLEventWriter fwriter = writer;
//		
//		Thread t = new Thread() {
//			/**
//			 * @param reader
//			 * @param writer
//			 * @throws XMLStreamException
//			 */
//			private void processXMLEvent(XMLEventReader reader, 
//					XMLEventWriter writer) throws XMLStreamException {
//
//				if (!reader.hasNext()) return;
//				XMLEvent event = reader.nextEvent();
//					
//				if (event.isStartElement()) {
//					processStartElement(writer, event);
//				} else if (event.isCharacters()) {
//					processCharacters(writer, event);
//				} else {
//					processOtherEvent(writer, event);
//				}
//			}
//
//			private void processOtherEvent(XMLEventWriter writer, XMLEvent event) throws XMLStreamException {
//				writer.add(event);
//			}
//		
//			private void processCharacters(XMLEventWriter writer, XMLEvent event) throws XMLStreamException {
//				String data = event.asCharacters().getData().replace('\r', ' ');
//				writer.add(eventFactory.createCharacters(data));
//			}
//			private void processStartElement(XMLEventWriter writer, XMLEvent event) throws XMLStreamException {
//				StartElement el = event.asStartElement();
//				
//				Attribute attr = el.getAttributeByName(new QName("id"));
//				if (attr == null) {
//					writer.add(el);
//					return;
//				} else if (!attr.getValue().equals("") && !attr.getValue().equals("0")) {
//					writer.add(el);
//					return;
//				}
//				
//				Iterator iter = el.getAttributes();
//				
//				ArrayList<Attribute> newAttrs = new ArrayList<Attribute>();
//				while (iter.hasNext()) {
//					attr = (Attribute)iter.next();
//					
//					if (attr.getName().equals("id")) {
//						attr = eventFactory.createAttribute("id", String.valueOf(AIMDocPreprocessor.generator.nextInt()));
//					}
//					newAttrs.add(attr);
//				}
//		
//				QName qn = el.getName();
//				StartElement el2 = eventFactory.createStartElement(qn.getPrefix(), qn.getNamespaceURI(), qn.getLocalPart(), newAttrs.iterator(), el.getNamespaces(), el.getNamespaceContext()); 
//				writer.add(el2);
//			}
//
//			@Override
//			public void run() {
//				// now write to the output stream.  for this test, use a zip stream.
//				// this is really to deal with the fact that we don't have a good way to delimit the files.
//				
//				try {
//					while (freader.hasNext()) {
//							processXMLEvent(freader, fwriter);
//					}
//				} catch (XMLStreamException e) {
//					System.err.println("Error processing the xml stream: " + e.getMessage());
//					e.printStackTrace();
//				} finally {
//					try {
//						fwriter.flush();
//						fwriter.close();
//					} catch (XMLStreamException e) {
//						System.err.println("Error closing the output stream: " + e.getMessage());	
//						e.printStackTrace();
//					}
//					try {
//						freader.close();
//					} catch (XMLStreamException e) {
//						System.err.println("Error closing the input stream: " + e.getMessage());	
//						e.printStackTrace();
//					}
//				}
//			}
//		};
//
//		t.start();	
//	
//		return pis;
	}

	private static Random generator = new Random(System.currentTimeMillis());


	private synchronized int getId() {
		return AIMDocPreprocessor.generator.nextInt();
	}

	private String transform(String aimXML, String splitter) {
		// remove the carriage return just in case
		String[] tokens = aimXML.split(splitter);
		StringBuffer buf = new StringBuffer();
		buf.append(tokens[0]);
		for (int i = 1; i < tokens.length; i++) {
			buf.append(" id=\"");
			buf.append(this.getId());
			buf.append("\"");
			buf.append(tokens[i]);
		}
		return buf.toString();
	}
	
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {

		AIMDocPreprocessor proc = new AIMDocPreprocessor();
		
		// arg 0 is the dir name.
		File dir = new File(args[0]);
		File[] files = dir.listFiles(new FilenameFilter() {
			
			public boolean accept(File arg0, String arg1) {
				if (arg1.endsWith(".xml")) return true;
				return false;
			}
		});
		
		for (File f : files) {
			StringBuffer buf = new StringBuffer();
			char[] data = new char[8192];
			int len = 0;
			String output;
			
			String filename = f.getAbsolutePath();
			File f2 = new File(filename.substring(0, filename.lastIndexOf(".xml")) + ".new.xml");
			FileWriter fos = new FileWriter(f2);
			try {
				FileReader reader = new FileReader(f);
				while ((len = reader.read(data)) >= 0 ) {
					buf.append(data, 0, len);
				}
				reader.close();
				output = proc.transform(buf.toString(), EMPTY_ID);
				output = proc.transform(output, ZERO_ID);
				
				
				fos.write(output);
				fos.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}
