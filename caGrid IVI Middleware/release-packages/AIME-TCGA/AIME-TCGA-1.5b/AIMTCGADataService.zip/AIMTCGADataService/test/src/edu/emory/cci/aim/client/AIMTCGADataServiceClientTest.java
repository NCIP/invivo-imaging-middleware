package edu.emory.cci.aim.client;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import junit.framework.TestCase;

public class AIMTCGADataServiceClientTest extends TestCase {
	private static Logger log = Logger.getLogger(AIMTCGADataServiceClientTest.class.getCanonicalName()); 

	private AIMTCGADataServiceClient client;
	
	protected void setUp() throws Exception {
		super.setUp();
		
		String url = "http://node01.cci.emory.edu:8080/wsrf/services/cagrid/AIMTCGADataService";
		client = new AIMTCGADataServiceClient(url);
		
		try {
			FileHandler fh = new FileHandler("aimtcgatest.log");
			fh.setLevel(Level.ALL);
			fh.setFormatter(new SimpleFormatter());
			log.addHandler(fh);
			ConsoleHandler ch = new ConsoleHandler();
			ch.setLevel(Level.WARNING);
			log.addHandler(ch);
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testQuery() {
		  File dir = new File("test/resources/aimCQL");
		  File[] files = dir.listFiles(new FilenameFilter() {

			public boolean accept(File arg0, String arg1) {
				return arg1.endsWith(".xml");
			}
		  });
		  
		  for (File f : files) {
			  log.info(f.getAbsolutePath());
			  try {
				  client.queryBySOAP(f.getAbsolutePath(), client);
			  } catch (Exception e) {
				  log.severe(e.getMessage());
				  e.printStackTrace();
			  }
		  }
	}
	public void testSubmit() throws IOException {
		  client.submitBySoap("28263f74-4372-4570-b3af-dc544b5ecadb", client);
	}

}
