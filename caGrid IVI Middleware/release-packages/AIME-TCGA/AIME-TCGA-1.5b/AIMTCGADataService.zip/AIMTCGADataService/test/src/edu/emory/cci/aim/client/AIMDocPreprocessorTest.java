package edu.emory.cci.aim.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.ByteBuffer;

import edu.emory.cci.utils.common.FileUtils;
import edu.emory.cci.utils.xml.TransformException;
import junit.framework.TestCase;

public class AIMDocPreprocessorTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testAIMDocPreprocessor() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		// test that we can do a class.forname
		Class c = Class.forName(AIMDocPreprocessor.class.getCanonicalName());
		assertNotNull(c);
		Object o = c.newInstance();
		assertNotNull(o);
		assertTrue(o instanceof AIMDocPreprocessor);
	}

	public void testTransformString() throws IOException, TransformException {
		AIMDocPreprocessor proc = new AIMDocPreprocessor();
		String str = FileUtils.readTextFile(new File("test/resources/aimdocs/0022BaselineA_Model.xml"));
		assertTrue(str.contains(" id=\"0\""));
		String newStr = proc.transform(str);
		assertFalse(newStr.contains(" id=\"0\""));
	}
	public void testTransformStream() throws IOException, TransformException {
		AIMDocPreprocessor proc = new AIMDocPreprocessor();
		File f = new File("test/resources/aimdocs/0022BaselineA_Model.xml");
		InputStream is = new FileInputStream(f);
		byte[] buf = new byte[(int)f.length() * 2];
		int read = is.read(buf);
		System.out.println(new String(buf, 0, read));

		is = new FileInputStream(f);
		InputStream is2 = proc.transform(is);
		
		buf = new byte[(int)f.length() * 2];
		read = is2.read(buf);
		System.out.println(new String(buf, 0, read));
	}

}
