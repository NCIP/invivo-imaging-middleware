package edu.emory.cci.aim.client;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import junit.framework.TestCase;
import gov.nih.nci.cagrid.data.faults.MalformedQueryExceptionType;
import gov.nih.nci.cagrid.data.faults.QueryProcessingExceptionType;

public class AIMTCGADataServiceClientStressTest extends TestCase {
	private static Logger log = Logger.getLogger(AIMTCGADataServiceClientStressTest.class.getCanonicalName()); 

	private AIMTCGADataServiceClient client;
	
	protected void setUp() throws Exception {
		super.setUp();
		
		String url = "http://node01.cci.emory.edu:8080/wsrf/services/cagrid/AIMTCGADataService";
		client = new AIMTCGADataServiceClient(url);
		
		try {
			FileHandler fh = new FileHandler("aimtcgastresstest.log");
			fh.setLevel(Level.ALL);
			fh.setFormatter(new SimpleFormatter());
			log.addHandler(fh);
			ConsoleHandler ch = new ConsoleHandler();
			ch.setLevel(Level.WARNING);
			log.addHandler(ch);
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testQuery() throws MalformedQueryExceptionType, QueryProcessingExceptionType, RemoteException {
		  long counter = 0;
		  while (counter < 10000) {
			  System.out.print("iteration " + counter + ", ");
			  counter ++;
			  client.queryBySOAPConciseOutput("E:/Dev/src/ivi/branches/SilverReview/services/AIMTCGADataService/test/resources/AIMTCGAAllImageAnnotationsCQL.xml",
				  client);
		  }
	}



}
