package edu.emory.cci.bindaas.authz.core;

import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class StandaloneServer {
	private String host = "localhost";
	private String port = "9112";
	private String contextRoot = "AuthorizationService";

	public void start(Object serviceObject) throws Exception {
		
		
		JAXRSServerFactoryBean rs = new JAXRSServerFactoryBean();
		rs.setAddress("http://" + host + ":" + port + "/" + contextRoot);
		rs.setServiceBeanObjects(serviceObject);
		rs.setTransportId("http://cxf.apache.org/transports/http");
		rs.create();
	}

	public static void main(String[] args) throws Exception {
		StandaloneServer server = new StandaloneServer();
		server.setHost(System.getProperty("host")!=null ? System.getProperty("host") : server.getHost());
		server.setPort(System.getProperty("port")!=null ? System.getProperty("port") : server.getPort());
		
		String appContextFile = System.getProperty("appContext")!=null ? System.getProperty("appContext") : null;
		
		ApplicationContext context = null;
		if(appContextFile != null)
		{
			 context = new FileSystemXmlApplicationContext(appContextFile);
		}
		else
		{
			 context = new ClassPathXmlApplicationContext("applicationContext.xml");
		}
		
		Object authzServiceBean = context.getBean("authorizationService");
		server.start(authzServiceBean);
		
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}
}
