package edu.emory.cci.bindaas.authz.rest;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import edu.emory.cci.bindaas.authz.core.IEnforcementPointProxy;


public class AuthorizationService {

	private IEnforcementPointProxy proxy;
	private Log log = LogFactory.getLog(getClass());

	
	
	public IEnforcementPointProxy getProxy() {
		return proxy;
	}

	public void setProxy(IEnforcementPointProxy proxy) {
		this.proxy = proxy;
	}

	@GET
	@Path("info")
	public String getInfo()
	{
		return "I am Alive";
	}

	@POST
	@Path("request/evaluate")
	public Response getDecision(@FormParam("request") String xacmlRequest) {
		try {
			log.debug("Servicing authorization request");
			return getSuccessResponse(proxy.getDecision(xacmlRequest));
		} catch (Exception e) {
			log.error(e);
			return getErrorResponse("Error getting authz decision");
		}

	}

	private Response getSuccessResponse(String message) {
		return Response.ok().entity(message).build();
	}

	private Response getErrorResponse(String message) {
		return Response.serverError().entity(message).build();
	}
}
