package edu.emory.cci.bindaas.authz.core;

public interface IEnforcementPointProxy {

	public String getDecision(String request) throws Exception;
}
