package edu.emory.cci.bindaas.authz.test;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;

import org.apache.cxf.helpers.IOUtils;
import org.junit.Test;


import edu.emory.cci.bindaas.authz.wso2.EnforcementPointProxy;

public class AuthorizationServiceTest {

	String username = "testldap01";
	String password = "tldapz55";

	@Test
	public void testSimpleRequestResponse() throws Exception {
		System.setProperty("javax.net.ssl.trustStore",
				"/Users/Nadir/dev/wso2is-3.2.3/repository/resources/security/wso2carbon.jks");
		System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");
		EnforcementPointProxy requestPoint = new EnforcementPointProxy();
		requestPoint.setServerUrl("https://localhost:9443");
		requestPoint.setUsername(username);
		requestPoint.setPassword(password);
		requestPoint.init();

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		IOUtils.copy(
				new FileInputStream("src/test/resources/xacml_request.xml"),
				bos);
		String request = new String(bos.toByteArray());
		String result = requestPoint.getDecision(request);
		System.out.println(result);
	}

	@Test
	public void testCachedRequestResponse() throws Exception {
		System.setProperty("javax.net.ssl.trustStore",
				"/Users/Nadir/dev/wso2is-3.2.3/repository/resources/security/wso2carbon.jks");
		System.setProperty("javax.net.ssl.trustStorePassword", "wso2carbon");
		EnforcementPointProxy requestPoint = new EnforcementPointProxy();
		requestPoint.setServerUrl("https://localhost:9443");
		requestPoint.setUsername(username);
		requestPoint.setPassword(password);
		requestPoint.init();
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		IOUtils.copy(
				new FileInputStream("src/test/resources/xacml_request.xml"),
				bos);
		String request = new String(bos.toByteArray());
		
	
		// first time
		String result = requestPoint.getDecision( request);
		System.out.println(result);
		
		
		
	}

}
