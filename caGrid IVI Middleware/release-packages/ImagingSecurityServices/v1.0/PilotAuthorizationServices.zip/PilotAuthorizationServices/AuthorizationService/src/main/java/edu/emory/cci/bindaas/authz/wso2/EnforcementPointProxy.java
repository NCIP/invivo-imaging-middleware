package edu.emory.cci.bindaas.authz.wso2;

import org.apache.axis2.AxisFault;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.authenticator.stub.AuthenticationAdminStub;
import org.wso2.carbon.identity.entitlement.ui.client.EntitlementServiceClient;

import edu.emory.cci.bindaas.authz.core.IEnforcementPointProxy;

public class EnforcementPointProxy implements IEnforcementPointProxy {
	private String username;
	private String password;
	private String serverUrl;
	private AuthenticationAdminStub authstub = null;
	private ConfigurationContext ctx;
	private EntitlementServiceClient entitlementServiceClient;
	private String cookie;
	private Log log = LogFactory.getLog(getClass());

	public void init() throws Exception{
		try {
			ctx = ConfigurationContextFactory
					.createConfigurationContextFromFileSystem(null, null);
			String authEPR = serverUrl + "/services/AuthenticationAdmin";
			authstub = new AuthenticationAdminStub(ctx, authEPR);

		} catch (AxisFault axisFault) {
			log.error("Cannot instantiate EnforcementPoint",axisFault);
			throw axisFault;
		}
	}

	public String getDecision(String xacmlRequest) throws Exception {

		String decision = null;
		try {
			if (this.cookie == null)
				throw new AxisFault("Cookie is null");
			entitlementServiceClient = new EntitlementServiceClient(
					this.cookie, serverUrl + "/services/", ctx);
			decision = entitlementServiceClient.getDecision(xacmlRequest
					.toString());
		} catch (AxisFault fault) {
			log.warn(
					"Cookie may have expired trying again by obtaining new cookie",
					fault);
			this.cookie = login(username, password);
			entitlementServiceClient = new EntitlementServiceClient(
					this.cookie, serverUrl + "/services/", ctx);
			decision = entitlementServiceClient.getDecision(xacmlRequest
					.toString());
		}

		log.debug("request \n" + xacmlRequest);
		log.debug("wso2 returned [" + decision + "]");
		return decision;

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getServerUrl() {
		return serverUrl;
	}

	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}

	public String login(String username, String password) throws Exception {
		String authCookie = null;
		ServiceClient client = authstub._getServiceClient();
		Options options = client.getOptions();
		options.setManageSession(true);
		options.setProperty(
				org.apache.axis2.transport.http.HTTPConstants.COOKIE_STRING,
				authCookie);

		boolean loggedIn = authstub.login(username, password, serverUrl);
		if (loggedIn) {
			log.info("The user " + username + " logged in successfully.");
			authCookie = (String) authstub._getServiceClient()
					.getServiceContext()
					.getProperty(HTTPConstants.COOKIE_STRING);
		} else {
			String errorMessage = "Error logging in " + username;
			log.error(errorMessage);
			throw new Exception(errorMessage);
		}
		return authCookie;
	}
}
