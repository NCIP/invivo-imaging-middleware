package edu.emory.cci.cagrid.restplugin.transform;

public interface ISerializer <T> {

	public String serialize(T object) throws TransformationException;
}
