package edu.emory.cci.cagrid.restplugin.test;

import static org.junit.Assert.*;
import gov.nih.nci.cagrid.cqlquery.CQLQuery;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.cxf.helpers.IOUtils;
import org.apache.http.client.methods.HttpPost;
import org.globus.wsrf.encoding.DeserializationException;
import org.globus.wsrf.encoding.ObjectDeserializer;
import org.junit.Test;
import org.xml.sax.InputSource;

public class TestService {

	
	@Test
	public void testQuery() throws Exception
	{
		String cqlQueryFile = "src/test/resources/retrieveAllAnnotations.cql";
		String url = "http://localhost:9089/AIM3DataService/query";
//		CQLQuery newQuery = null;
//		try {
//			InputSource queryInput = new InputSource(new FileReader(cqlQueryFile));
//			newQuery = (CQLQuery) ObjectDeserializer.deserialize(queryInput,
//					CQLQuery.class);
//		} catch (FileNotFoundException e) {
//			fail("test Query XML file not found");
//		} catch (DeserializationException e) {
//			fail("test Query XML file could not be deserialized");
//		}
//		assertNotNull(newQuery);
		
		FileInputStream fis = new FileInputStream(cqlQueryFile);
		
		String content = IOUtils.readStringFromStream(fis);
		
		String serverResponse = makeCall(url, content);
		System.out.println(serverResponse);
		
	}
	
	
	public String makeCall(String url, String content) throws IOException
	{
		HttpClient client = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		postMethod.addParameter("request", content);
		
		 NameValuePair[] data = {
		          new NameValuePair("request", content),
		         
		        };
		 
		postMethod.setRequestBody(content);
		client.executeMethod(postMethod);
		
		InputStream in = postMethod.getResponseBodyAsStream();
		String response = IOUtils.readStringFromStream(in);
		postMethod.releaseConnection();
		return response;
	}
	
	public InputStream makeCallForStream(String url, String content) throws IOException
	{
		HttpClient client = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		postMethod.addParameter("request", content);
		
		 NameValuePair[] data = {
		          new NameValuePair("request", content),
		         
		        };
		 
		postMethod.setRequestBody(content);
		client.executeMethod(postMethod);
		InputStream in = postMethod.getResponseBodyAsStream();

		return in;
	}
	
	@Test
	public void testRetrieve() throws Exception
	{
		String cqlQueryFile = "src/test/resources/retrieveAllAnnotations.cql";
		String url = "http://localhost:9089/AIM3DataService/retrieve";
		
		FileInputStream fis = new FileInputStream(cqlQueryFile);
		
		String content = IOUtils.readStringFromStream(fis);
		
		InputStream stream = makeCallForStream(url, content);
		FileOutputStream fos = new FileOutputStream("response.zip");
		IOUtils.copy(stream, fos);
	}
}
