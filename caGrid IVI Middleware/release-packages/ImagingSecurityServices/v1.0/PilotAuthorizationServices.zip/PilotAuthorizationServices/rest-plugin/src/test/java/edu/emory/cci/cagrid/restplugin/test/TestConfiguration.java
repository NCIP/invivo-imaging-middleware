package edu.emory.cci.cagrid.restplugin.test;

import java.io.FileReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.cxf.helpers.IOUtils;
import org.junit.Test;

import com.google.gson.Gson;

import edu.emory.cci.cagrid.restplugin.conf.Operation;
import edu.emory.cci.cagrid.restplugin.conf.ServiceConfiguration;

public class TestConfiguration {

	@Test
	public void testToJson()
	{
		ServiceConfiguration config = new ServiceConfiguration();
		config.setBaseUrl("AIM3DataService");
		config.setDeserialziers(new HashMap<String, String>());
		config.setSerializers(new HashMap<String, String>());
		config.setTargetServiceUrl("http://ivi02.cci.emory.edu:9090/wsrf/services/cagrid/AIM3DataService");
		
		
		Map<String,Operation> mapOfOperation = new HashMap<String,Operation>();
		
		Operation queryOperation = new Operation();
		queryOperation.setType("na");
		queryOperation.setName("query");
		queryOperation.setUrl("query");
		queryOperation.setInputArguments(Arrays.asList(new String[]{ "gov.nih.nci.cagrid.cqlquery.CQLQuery"   }));
		
		Operation submitOperation = new Operation();
		submitOperation.setType("submit");
		submitOperation.setName("submitByTransfer");
		submitOperation.setUrl("submit");
		submitOperation.setInputArguments(Arrays.asList(new String[]{  }));
		
		Operation retrieveOperation = new Operation();
		retrieveOperation.setType("retrieve");
		retrieveOperation.setName("queryByTransfer");
		retrieveOperation.setUrl("retrieve");
		retrieveOperation.setInputArguments(Arrays.asList("gov.nih.nci.cagrid.cqlquery.CQLQuery"));
		
		
		mapOfOperation.put("query", queryOperation);
		mapOfOperation.put("submitByTransfer", submitOperation);
		mapOfOperation.put("queryByTransfer", retrieveOperation);
		
		
		config.setOperations(mapOfOperation);
		
		Gson gson = new Gson();
		System.out.println(gson.toJson(config));
	}
	
	@Test
	public void fromJson()  throws Exception
	{
		Gson gson = new Gson();
		FileReader reader = new FileReader("src/main/resources/service.conf.json");
		StringWriter sw = new StringWriter();
		IOUtils.copy(reader, sw, 2048);
		ServiceConfiguration serviceConfig = gson.fromJson(sw.toString(),
				ServiceConfiguration.class);
		System.out.println(serviceConfig);
	}
}
