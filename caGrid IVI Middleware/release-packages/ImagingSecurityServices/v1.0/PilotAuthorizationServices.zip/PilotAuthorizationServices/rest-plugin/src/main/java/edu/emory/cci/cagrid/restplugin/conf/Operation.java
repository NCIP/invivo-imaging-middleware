package edu.emory.cci.cagrid.restplugin.conf;

import java.util.List;

public class Operation {

	private String name;
	private List<String> inputArguments;
	private String url;
	private String type; // submit / retrieve / na
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getInputArguments() {
		return inputArguments;
	}
	public void setInputArguments(List<String> inputArguments) {
		this.inputArguments = inputArguments;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
