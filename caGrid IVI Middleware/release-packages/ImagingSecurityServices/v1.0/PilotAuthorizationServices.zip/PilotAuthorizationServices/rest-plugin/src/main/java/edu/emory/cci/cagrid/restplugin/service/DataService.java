package edu.emory.cci.cagrid.restplugin.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.jaxrs.interceptor.JAXRSInInterceptor;
import org.apache.cxf.message.Message;
import org.cagrid.transfer.context.client.TransferServiceContextClient;
import org.cagrid.transfer.context.client.helper.TransferClientHelper;
import org.cagrid.transfer.context.stubs.types.TransferServiceContextReference;
import org.cagrid.transfer.descriptor.Status;

import com.google.gson.Gson;

import edu.emory.cci.cagrid.restplugin.conf.Operation;
import edu.emory.cci.cagrid.restplugin.conf.ServiceConfiguration;
import edu.emory.cci.cagrid.restplugin.core.OperationEntry;
import edu.emory.cci.cagrid.restplugin.core.RequestDescriptor;
import edu.emory.cci.cagrid.restplugin.transform.IDeserializer;
import edu.emory.cci.cagrid.restplugin.transform.ISerializer;

public class DataService extends JAXRSInInterceptor {

	public DataService() {
		super();

	}

	@Override
	public void handleMessage(Message message) {
		String httpMethod = (String) message.get(Message.HTTP_REQUEST_METHOD);
		if (httpMethod.equalsIgnoreCase("POST") == true)
		{
			Response response = handleRequest(message);
			message.getExchange().put(Response.class, response);
		}
		
	}

	private Object serviceProxy;
	private Map<String, OperationEntry> mapOfOperations;
	private Map<String, ISerializer> mapOfSerializers;
	private Map<String, IDeserializer> mapOfDeserializers;
	private Log log = LogFactory.getLog(getClass());
	private String serviceConfigurationFile;
	private String serviceJars;
	private Gson gson = new Gson();
	private String serverUrl;
	
	public String getServiceJars() {
		return serviceJars;
	}

	public void setServiceJars(String serviceJars) {
		this.serviceJars = serviceJars;
	}

	public String getServerUrl() {
		return serverUrl;
	}

	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}

	public Object getServiceProxy() {
		return serviceProxy;
	}

	public void setServiceProxy(Object serviceProxy) {
		this.serviceProxy = serviceProxy;
	}

	public Map<String, OperationEntry> getMapOfOperations() {
		return mapOfOperations;
	}

	public void setMapOfOperations(Map<String, OperationEntry> mapOfOperations) {
		this.mapOfOperations = mapOfOperations;
	}

	public Map<String, ISerializer> getMapOfSerializers() {
		return mapOfSerializers;
	}

	public void setMapOfSerializers(Map<String, ISerializer> mapOfSerializers) {
		this.mapOfSerializers = mapOfSerializers;
	}

	public Map<String, IDeserializer> getMapOfDeserializers() {
		return mapOfDeserializers;
	}

	public void setMapOfDeserializers(
			Map<String, IDeserializer> mapOfDeserializers) {
		this.mapOfDeserializers = mapOfDeserializers;
	}

	public String getServiceConfigurationFile() {
		return serviceConfigurationFile;
	}

	public void setServiceConfigurationFile(String serviceConfigurationFile) {
		this.serviceConfigurationFile = serviceConfigurationFile;
	}

	public void init() throws Exception {
		File file = new File(serviceConfigurationFile);

		try {
			FileReader reader = new FileReader(file);
			StringWriter sw = new StringWriter();
			IOUtils.copy(reader, sw, 2048);
			ServiceConfiguration serviceConfig = gson.fromJson(sw.toString(),
					ServiceConfiguration.class);
			init(serviceConfig);
		} catch (Exception e) {
			log.error(e);
			throw new Exception("Service could not be configured");
		}

	}

	public void init(ServiceConfiguration serviceConfiguration)
			throws Exception {

		// initialize the service proxy
		
		String targetServiceUrl = serviceConfiguration.getTargetServiceUrl();
		log.info("Initializing the service proxy pointing to ["
				+ targetServiceUrl + "]");

		Class serviceClass = Class.forName(serviceConfiguration
				.getServiceProxyClass());
		Constructor[] constructors = serviceClass.getDeclaredConstructors();
		Constructor stringArgConstructor = null;

		for (Constructor cons : constructors) {
			if (cons.getParameterTypes().length == 1
					&& cons.getParameterTypes()[0]
							.equals(java.lang.String.class)) {
				stringArgConstructor = cons;
			}
		}

		serviceProxy = stringArgConstructor.newInstance(targetServiceUrl);
		log.info("Service Proxy Initialized");

		// register serializers

		for (String className : serviceConfiguration.getSerializers().keySet()) {
			String serializerClass = serviceConfiguration.getSerializers().get(
					className);
			ISerializer serializer = (ISerializer) Class.forName(
					serializerClass).newInstance();
			mapOfSerializers.put(className, serializer);
			log.info("Registering Serializer for [" + className + "]=["
					+ serializerClass + "]");
		}

		// register deserializers
		for (String className : serviceConfiguration.getDeserialziers()
				.keySet()) {
			String deserializerClass = serviceConfiguration.getDeserialziers()
					.get(className);
			IDeserializer deserializer = (IDeserializer) Class.forName(
					deserializerClass).newInstance();
			mapOfDeserializers.put(className, deserializer);
			log.info("Registering Deserializer for [" + className + "]=["
					+ deserializerClass + "]");
		}

		// Scan through each method of this class and configure if required
		mapOfOperations = new HashMap<String, OperationEntry>();
		Method[] declaredMethods = serviceProxy.getClass().getMethods();
		for (Method method : declaredMethods) {
			if (serviceConfiguration.getOperations().containsKey(
					method.getName())) {
				Operation operation = serviceConfiguration.getOperations().get(
						method.getName());
				// validate return type constriant
				Class returnType = method.getReturnType();
				int argumentCount = method.getParameterTypes().length;

				if (operation.getType().equals("retrieve")
						&& returnType
								.equals(TransferServiceContextReference.class)
						&& argumentCount <= 1) {
					// return type must be Tx context and argument should be 1
					if (argumentCount == 1) {
						Class clazz = method.getParameterTypes()[0];
						if (mapOfDeserializers.containsKey(clazz.getName()) == false)
							continue;
					}

		
					OperationEntry entry = new OperationEntry();
					entry.setMethod(method);
					entry.setOperation(operation);
					String key = serviceConfiguration.getBaseUrl() + "/"
							+ operation.getUrl();
					mapOfOperations.put(key, entry);
					log.info("Mapping URL [" + this.serverUrl + "/" + key
							+ "] to method=[" + method.getName()
							+ "] of type=[retrieve]");

				} else if (operation.getType().equals("submit")
						&& returnType
								.equals(TransferServiceContextReference.class)
						&& argumentCount == 0) {
					// return type must be Tx context and argument = 0

					OperationEntry entry = new OperationEntry();
					entry.setMethod(method);
					entry.setOperation(operation);
					String key = serviceConfiguration.getBaseUrl() + "/"
							+ operation.getUrl();
					mapOfOperations.put(key, entry);
					log.info("Mapping URL [" + this.serverUrl + "/" + key
							+ "] to method=[" + method.getName()
							+ "] of type=[submit]");

				} else if (operation.getType().equals("simple")
						&& argumentCount <= 1) {
					// return type can be any and argument <= 1
					if (argumentCount == 1) {
						Class clazz = method.getParameterTypes()[0];
						if (mapOfDeserializers.containsKey(clazz.getName()) == false)
							continue;
					}

					OperationEntry entry = new OperationEntry();
					entry.setMethod(method);
					entry.setOperation(operation);
					String key = serviceConfiguration.getBaseUrl() + "/"
							+ operation.getUrl();
					mapOfOperations.put(key, entry);

					log.info("Mapping URL [" + this.serverUrl + "/" + key
							+ "] to method=[" + method.getName()
							+ "] of type=[simple]");
				}

			}

		}

	}

	public Response handleRequest(Message message) {

		String requestPath = (String) message.get(Message.PATH_INFO).toString();
		String operationUrl = null;

		for (String key : mapOfOperations.keySet()) {
			if (requestPath.endsWith(key)) {
				operationUrl = key;
				break;
			}
		}

		if (operationUrl != null) {
			OperationEntry operationEntry = mapOfOperations.get(operationUrl);
			RequestDescriptor requestDescriptor = message
					.get(RequestDescriptor.class);

			if (requestDescriptor == null) {
				log.error("RequestDescriptor not set");
				return createErrorResponse("Internal Service Error: RequestDescriptor not set");
			}

			if (operationEntry.getOperation().getType().equals("simple")
					&& requestDescriptor.isMime() == false) {
				String response;
				try {
					String request = requestDescriptor.getPayloadString();
					response = handleSimple(operationEntry.getMethod(), request);
					return createOkResponse(response);
				} catch (Exception e) {
					log.error(e);
					return createErrorResponse("Internal Service Error: "
							+ e.getMessage());
				}

			} else if (operationEntry.getOperation().getType()
					.equals("retrieve")
					&& requestDescriptor.isMime() == false) {
				InputStream is;
				try {
					String request = requestDescriptor.getPayloadString();
					is = handleRetrieve(operationEntry.getMethod(), request);
				} catch (Exception e) {
					log.error(e);
					return createErrorResponse("Internal Service Error: "
							+ e.getMessage());
				}
				return createOkResponse(is);
			} else if (operationEntry.getOperation().getType().equals("submit")
					&& requestDescriptor.isMime() == true) {
				try {

					InputStream dataStream = requestDescriptor
							.getPayloadStream();
					handleSubmit(operationEntry.getMethod(), dataStream);
					return createOkResponse("Upload Successfull");

				} catch (Exception e) {
					log.error(e);
					return createErrorResponse("Internal Service Error: "
							+ e.getMessage());
				}
			} else {
				return createErrorResponse("Internal Service Error: Configuration not initialized correctly");
			}
		} else {
			return createErrorResponse("Invalid Request Url. No matching operation found");
		}

	}

	private Object deserialize(String content, Class clazz) throws Exception {
		IDeserializer deserializer = mapOfDeserializers.get(clazz.getName());
		if (deserializer != null) {
			log.debug("Deserializing Content\n" + content);
			Object object = deserializer.deserialize(content);
			return object;
		} else {
			throw new Exception("No Deserializer found for type ["
					+ clazz.getName() + " ]");
		}

	}

	private String serialize(Object object) throws Exception {
		ISerializer serializer = mapOfSerializers.get(object.getClass()
				.getName());
		if (serializer != null) {
			log.debug("Serializing object of type [" + object.getClass().getName() + "]");
			String content = serializer.serialize(object);
			return content;
		} else {
			throw new Exception("No Serializer found for type ["
					+ object.getClass().getName() + " ]");
		}

	}

	// Invocation of target service method must return a Stream .
	public InputStream handleRetrieve(Method method, String request)
			throws Exception {

		Class parameterClazz = method.getParameterTypes()[0]; // currently only
																// one parameter
																// method calls
																// permitted
		Object inputParameter = deserialize(request, parameterClazz);
		log.info("Invoking method=[" + method.getName() + "] with argument(s) [" + inputParameter + "]");
		InputStream retVal = null;
		TransferServiceContextReference txReference = (TransferServiceContextReference) method
				.invoke(serviceProxy, inputParameter);
		TransferServiceContextClient tclient = new TransferServiceContextClient(
				txReference.getEndpointReference());
		retVal = TransferClientHelper.getData(tclient
				.getDataTransferDescriptor());
		log.info("Invocation completed. Processing response");
		return retVal;
	}

	// User uploaded some data so retrieve it
	public void handleSubmit(Method method, InputStream dataStream)
			throws Exception {
		log.info("Invoking method=[" + method.getName() + "] ");
		File tempFile = new File(UUID.randomUUID().toString());
		IOUtils.copy(dataStream, new FileOutputStream(tempFile));
		FileInputStream fis = new FileInputStream(tempFile);
		TransferServiceContextReference txReference = (TransferServiceContextReference) method
				.invoke(serviceProxy);
		TransferServiceContextClient tclient = new TransferServiceContextClient(
				txReference.getEndpointReference());
		TransferClientHelper.putData(fis, tempFile.length(),
				tclient.getDataTransferDescriptor());
		// tell the resource that the data has been uploaded.
		tclient.setStatus(Status.Staged);
		fis.close();
		tempFile.delete();
		log.info("Invocation completed. Processing response");
	}

	public String handleSimple(Method method, String request) throws Exception {
		Object retVal = null;
		if (method.getParameterTypes().length == 1) {
			
			Class parameterClazz = method.getParameterTypes()[0]; // currently
																	// only
																	// one
																	// parameter
																	// method
																	// calls
																	// permitted
			Object inputParameter = deserialize(request, parameterClazz);
			log.info("Invoking method=[" + method.getName() + "] with argument(s) [" + inputParameter + "]");

			retVal = method.invoke(serviceProxy, inputParameter);
		} else if (method.getParameterTypes().length == 0) {
			log.info("Invoking method=[" + method.getName() + "]");
			retVal = method.invoke(serviceProxy);
		} else
			throw new Exception(
					"Invalid number of arguments to invoke this method");

		String response = serialize(retVal);
		log.info("Invocation completed. Processing response");
		return response;
	}

	private Response createOkResponse(InputStream content) {
		return Response.ok().entity(content).build();
	}

	private Response createOkResponse(String content) {
		return Response.ok().entity(content).build();
	}

	private Response createErrorResponse(String content) {
		return Response.serverError().entity(content).build();
	}

}
