package edu.emory.cci.cagrid.restplugin.core;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.interceptor.AttachmentInInterceptor;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import edu.emory.cci.bindaas.rest.security.AbstractAuthenticationHandler;
import edu.emory.cci.bindaas.rest.security.audit.AuditInLogger;
import edu.emory.cci.cagrid.restplugin.service.DataService;
import edu.emory.cci.cagrid.restplugin.service.Info;
import edu.emory.cci.cagrid.restplugin.service.ParseInterceptor;

public class Server {

	private String port = "9089";
	private String host = "localhost";
	private String appContextFile = "applicationContext.xml";
	private String serviceConfig;
	private String cagridJars;
	public String getServiceConfig() {
		return serviceConfig;
	}

	public void setServiceConfig(String serviceConfig) {
		this.serviceConfig = serviceConfig;
	}

	public String getCagridJars() {
		return cagridJars;
	}

	public void setCagridJars(String cagridJars) {
		this.cagridJars = cagridJars;
	}

	private ApplicationContext appContext;
	private org.apache.cxf.endpoint.Server srv = null;
	private boolean secure = false;
	private boolean audit = true;
	private boolean authorizationMethodLevel = false;
	private Log log = LogFactory.getLog(getClass());

	
	
	public boolean isAuthorizationMethodLevel() {
		return authorizationMethodLevel;
	}

	public void setAuthorizationMethodLevel(boolean authorizationMethodLevel) {
		this.authorizationMethodLevel = authorizationMethodLevel;
	}

	

	
	public boolean isAudit() {
		return audit;
	}

	public void setAudit(boolean audit) {
		this.audit = audit;
	}

	

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}


	public String getAppContextFile() {
		return appContextFile;
	}

	public void setAppContextFile(String appContextFile) {
		this.appContextFile = appContextFile;
	}

	public ApplicationContext getAppContext() {
		return appContext;
	}

	public void setAppContext(ApplicationContext appContext) {
		this.appContext = appContext;
	}

	public void start() throws Exception {

		if (appContext == null)
			appContext = new ClassPathXmlApplicationContext(appContextFile);
		DataService dataService = (DataService) appContext
				.getBean("dataService");
		

		JAXRSServerFactoryBean rs = new JAXRSServerFactoryBean();
		rs.setAddress("http://" + host + ":" + port);

		rs.setTransportId("http://cxf.apache.org/transports/http");
		

		// Configure Audit

		if (audit == true) {
			log.debug("Adding Audit Interceptor");
			AuditInLogger logger = (AuditInLogger) appContext
					.getBean("auditLoggerInterceptor");
			rs.getInInterceptors().add(logger);
		}

		// Configure Security

		if (secure == true) {
			log.debug("Adding Security Interceptor");
			AbstractAuthenticationHandler authenticationHandler = (AbstractAuthenticationHandler) appContext
					.getBean("authenticationHandler");
			
			// set method level authorization
			
			authenticationHandler.setEnableAuthorization(authorizationMethodLevel);
			
						
			// set audit
			authenticationHandler.setEnableAudit(audit);
			rs.setProvider(authenticationHandler);

		}

		rs.getInInterceptors().add(dataService);
		rs.getInInterceptors().add(new ParseInterceptor());
		
		
		Info infoBean = (Info) appContext.getBean("infoBean");
		
		rs.setServiceBean(infoBean);
		// init dataService bean
		
		dataService.setServerUrl("http://" + host + ":" + port);
		dataService.setServiceConfigurationFile(serviceConfig);
		dataService.setServiceJars(cagridJars);
		dataService.init();
		srv = rs.create();

		
		log.info("Security is [" + (secure ? "enabled" : "disabled") + "]");
		log.info("Method Level Authorization is ["
				+ (this.authorizationMethodLevel ? "enabled" : "disabled") + "]");
		log.info("Audit is [" + (audit ? "enabled" : "disabled") + "]");
		log.info("Server in running at " + "http://" + host + ":" + port + "]");
		
	}

	public void stop() throws Exception {
		if (srv != null)
			srv.destroy();
	}

	
	public static void usage()
	{
		System.out.println("caGrid DataService REST plugin version 0.0.1");
		System.out.println("-Dhost=<host> Hostname to bind. Default=[localhost]");
		System.out.println("-Dport=<port> Port to bind. Default=[9099]");
		System.out.println("-Dconf=<configuration file> Required");
		System.out.println("-DcagridLib=<cagrid data service client jars path> Required");
		System.out.println("-Dsecure To start Server in secured mode. Default=[unsecure]");
		System.out.println("-Daudit=false Disable Audit. Default=[true]");
		System.out.println("-Dauthorization-method=<true/false> Enable method level authorization. Default=[false]");
		System.out.println("-Dlog=[debug,info,error] Logger level. Default=[info]");
		System.exit(0);
		
	}
	public static void main(String[] args) throws Exception {

		if(args.length > 0 && args[0].equals("help"))
		{
			usage();
		}
		Server server = new Server();
		
		if (System.getProperties().containsKey("conf")) {
			server.setServiceConfig(System.getProperties().get("conf").toString());
		}
		else throw new Exception("Mandatory parameter [conf] not provided. Please use -Dconf=<configuration file>");
		
		if (System.getProperties().containsKey("cagridLib")) {
			server.setCagridJars(System.getProperties().get("cagridLib").toString());
		}
		else throw new Exception("Mandatory parameter [cagridLib] not provided. Please use -DcagridLib=<cagrid data service client jars path>");
		
		
		server.setHost(System.getProperty("host") != null ? System
				.getProperty("host") : server.getHost());
		server.setPort(System.getProperty("port") != null ? System
				.getProperty("port") : server.getPort());
		
		if (System.getProperties().containsKey("secure")) {
			server.setSecure(true);
		}

		if (System.getProperties().containsKey("authorization-method")
				&& System.getProperties().get("authorization-method").toString().equalsIgnoreCase("true")) {
			server.setAuthorizationMethodLevel(true);
		}
		
		if (System.getProperties().containsKey("audit")
				&& System.getProperties().get("audit").equals("false")) {
			server.setAudit(false);
		}
		
		if (System.getProperties().containsKey("audit")
				&& System.getProperties().get("audit").equals("false")) {
			server.setAudit(false);
		}

		if (System.getProperties().containsKey("log")) {
			Logger rootLogger = Logger.getRootLogger();

			if (System.getProperties().get("log").equals("debug")) {
				rootLogger.setPriority(Priority.DEBUG);
			}

			if (System.getProperties().get("log").equals("info")) {
				rootLogger.setPriority(Priority.INFO);
			}

			if (System.getProperties().get("log").equals("error")) {
				rootLogger.setPriority(Priority.ERROR);
			}
		}

		String appContextFile = System.getProperty("appContext") != null ? System
				.getProperty("appContext") : null;
		if (appContextFile != null) {
			ApplicationContext context = new FileSystemXmlApplicationContext(
					appContextFile);
			server.setAppContext(context);
		}

		server.start();
	}

	public boolean isSecure() {
		return secure;
	}

	public void setSecure(boolean secure) {
		this.secure = secure;
	}
}
