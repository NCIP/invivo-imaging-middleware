package edu.emory.cci.cagrid.restplugin.transform;

import java.io.StringWriter;

import javax.xml.namespace.QName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.globus.wsrf.encoding.ObjectSerializer;
import org.globus.wsrf.encoding.SerializationException;

import gov.nih.nci.cagrid.cqlresultset.CQLQueryResults;

public class CQLQueryResultSerializer implements
		ISerializer<gov.nih.nci.cagrid.cqlresultset.CQLQueryResults> {

	private Log log = LogFactory.getLog(getClass());

	public String serialize(CQLQueryResults object)
			throws TransformationException {
		StringWriter sw = new StringWriter();
		try {
			ObjectSerializer.serialize(sw, object, new QName("cagrid"));
		} catch (SerializationException e) {
			log.error(e);
			throw new TransformationException(e);
		}

		return sw.toString();
	}

}
