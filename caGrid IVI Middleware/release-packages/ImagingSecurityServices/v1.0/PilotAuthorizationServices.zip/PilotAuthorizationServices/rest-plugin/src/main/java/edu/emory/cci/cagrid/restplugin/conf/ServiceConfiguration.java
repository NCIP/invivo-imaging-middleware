package edu.emory.cci.cagrid.restplugin.conf;

import java.util.List;
import java.util.Map;

public class ServiceConfiguration {

	private String serviceProxyClass;
	private String targetServiceUrl;
	
	public String getServiceProxyClass() {
		return serviceProxyClass;
	}
	public void setServiceProxyClass(String serviceProxyClass) {
		this.serviceProxyClass = serviceProxyClass;
	}
	public String getTargetServiceUrl() {
		return targetServiceUrl;
	}
	public void setTargetServiceUrl(String targetServiceUrl) {
		this.targetServiceUrl = targetServiceUrl;
	}
	public String getBaseUrl() {
		return baseUrl;
	}
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	
	public Map<String, Operation> getOperations() {
		return operations;
	}
	public void setOperations(Map<String, Operation> operations) {
		this.operations = operations;
	}
	public Map<String, String> getSerializers() {
		return serializers;
	}
	public void setSerializers(Map<String, String> serializers) {
		this.serializers = serializers;
	}
	public Map<String, String> getDeserialziers() {
		return deserialziers;
	}
	public void setDeserialziers(Map<String, String> deserialziers) {
		this.deserialziers = deserialziers;
	}
	private String baseUrl;
	private Map<String,Operation> operations;
	private Map<String,String> serializers;
	private Map<String,String> deserialziers;
	
}
