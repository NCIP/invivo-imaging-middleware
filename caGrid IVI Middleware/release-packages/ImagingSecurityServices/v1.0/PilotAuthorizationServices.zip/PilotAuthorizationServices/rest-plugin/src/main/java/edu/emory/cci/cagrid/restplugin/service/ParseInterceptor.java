package edu.emory.cci.cagrid.restplugin.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.attachment.AttachmentDeserializer;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

import edu.emory.cci.cagrid.restplugin.core.RequestDescriptor;

public class ParseInterceptor extends AbstractPhaseInterceptor<Message> {

	private Log log = LogFactory.getLog(getClass());

	public ParseInterceptor() {
		super(Phase.RECEIVE);
	}

	public ParseInterceptor(String phase) {
		super(phase);

	}

	public void handleMessage(Message message) throws Fault {
		String httpMethod = (String) message.get(Message.HTTP_REQUEST_METHOD);
		if (httpMethod.equalsIgnoreCase("POST") == false) {
//			Response resp = Response
//					.serverError()
//					.entity("Method not allowed. Only POST requests are accepted")
//					.build();
//			message.getExchange().put(Response.class, resp);
			
			return;// do nothing
		} else {
			String contentType = (String) message.get(Message.CONTENT_TYPE);
			RequestDescriptor descriptor = new RequestDescriptor();
			if (contentType!=null && contentType.contains("multipart")) {
				AttachmentDeserializer ad = new AttachmentDeserializer(message,
						Collections.singletonList("multipart"));
				try {
					ad.initializeAttachments();
					InputStream is = message.getContent(InputStream.class);
						
					descriptor.setMime(true);
					descriptor.setPayloadStream(is);
				} catch (IOException e) {
					log.error(e);
					Response resp  = JAXRSUtils.convertFaultToResponse(e, message);
					message.getExchange().put(Response.class, resp);
				}

			} else
			{ // extract request as plain text
				InputStream body = message.getContent(InputStream.class);
				try {
					String request = IOUtils.readStringFromStream(body);
					descriptor.setMime(false);
					descriptor.setPayloadString(request);
				} catch (IOException e) {
					log.error(e);
					Response resp  = JAXRSUtils.convertFaultToResponse(e, message);
					message.getExchange().put(Response.class, resp);
				}
			}
			
			message.put(RequestDescriptor.class, descriptor);

		}

	}

}
