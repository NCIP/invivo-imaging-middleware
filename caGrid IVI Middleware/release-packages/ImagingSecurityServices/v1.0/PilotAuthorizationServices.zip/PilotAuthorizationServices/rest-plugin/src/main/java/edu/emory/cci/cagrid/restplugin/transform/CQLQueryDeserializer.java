package edu.emory.cci.cagrid.restplugin.transform;

import gov.nih.nci.cagrid.cqlquery.CQLQuery;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.globus.wsrf.encoding.DeserializationException;
import org.globus.wsrf.encoding.ObjectDeserializer;
import org.xml.sax.InputSource;

public class CQLQueryDeserializer implements IDeserializer<CQLQuery> {

	private Log log = LogFactory.getLog(getClass());
	public CQLQuery deserialize(String data)
			throws TransformationException {
		
		InputStream is = new ByteArrayInputStream(data.getBytes());
		InputSource isource = new InputSource(is);
		try {
			CQLQuery cqlQuery = (CQLQuery) ObjectDeserializer.deserialize(isource, gov.nih.nci.cagrid.cqlquery.CQLQuery.class);
			return cqlQuery;
		} catch (DeserializationException e) {
			log.error(e);
			throw new TransformationException(e);
		}
	
	}

}
