package edu.emory.cci.cagrid.restplugin.transform;

public interface IDeserializer<T> {

	
	public T deserialize(String data) throws TransformationException;
}
