package edu.emory.cci.cagrid.restplugin.transform;

public class TransformationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TransformationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransformationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TransformationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TransformationException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
