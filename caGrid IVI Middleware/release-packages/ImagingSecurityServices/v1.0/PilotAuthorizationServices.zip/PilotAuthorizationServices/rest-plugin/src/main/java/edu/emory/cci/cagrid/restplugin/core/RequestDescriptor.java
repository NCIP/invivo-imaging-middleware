package edu.emory.cci.cagrid.restplugin.core;

import java.io.InputStream;

public class RequestDescriptor {

	private boolean isMime;
	private String payloadString;
	private InputStream payloadStream;
	public boolean isMime() {
		return isMime;
	}
	public void setMime(boolean isMime) {
		this.isMime = isMime;
	}
	
	public InputStream getPayloadStream() {
		return payloadStream;
	}
	public void setPayloadStream(InputStream payloadStream) {
		this.payloadStream = payloadStream;
	}
	public String getPayloadString() {
		return payloadString;
	}
	public void setPayloadString(String payloadString) {
		this.payloadString = payloadString;
	}
	
	
}
