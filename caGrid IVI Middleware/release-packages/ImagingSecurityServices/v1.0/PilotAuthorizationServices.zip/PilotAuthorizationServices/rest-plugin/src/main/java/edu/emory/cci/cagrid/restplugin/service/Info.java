package edu.emory.cci.cagrid.restplugin.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import edu.emory.cci.cagrid.restplugin.core.OperationEntry;

@Path("info")
public class Info {

	private DataService dataService;
	private String htmlCode;
	public DataService getDataService() {
		return dataService;
	}
	public void setDataService(DataService dataService) {
		this.dataService = dataService;
	}
	
	public String getHtmlCode() {
		return htmlCode;
	}
	public void setHtmlCode(String htmlCode) {
		this.htmlCode = htmlCode;
	}
	@GET
	public String info()
	{
		StringBuffer stringBuffer = new StringBuffer();
		for(String key : dataService.getMapOfOperations().keySet())
		{
			OperationEntry entry = dataService.getMapOfOperations().get(key);
			stringBuffer.append("<tr><td>").append(dataService.getServerUrl() + "/" + key).append("</td><td>").append(entry.getMethod().getName())
			.append("</td><td>").append(entry.getOperation().getType()).append("</td></tr>");
		}
		return htmlCode.replace("$content$", stringBuffer.toString());
	}
}
