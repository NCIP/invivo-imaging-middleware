package edu.emory.cci.cagrid.restplugin.core;

import java.lang.reflect.Method;

import edu.emory.cci.cagrid.restplugin.conf.Operation;

public class OperationEntry {

	private Method method;
	private Operation operation;
	
	public Method getMethod() {
		return method;
	}
	public void setMethod(Method method) {
		this.method = method;
	}
	public Operation getOperation() {
		return operation;
	}
	public void setOperation(Operation operation) {
		this.operation = operation;
	}
	
}
