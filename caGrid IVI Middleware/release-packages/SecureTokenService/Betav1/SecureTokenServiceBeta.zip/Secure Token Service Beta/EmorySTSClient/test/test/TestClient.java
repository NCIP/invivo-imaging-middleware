package test;

import junit.framework.TestCase;

import org.picketlink.identity.federation.api.wstrust.WSTrustClient;
import org.picketlink.identity.federation.api.wstrust.WSTrustClient.SecurityInfo;
import org.picketlink.identity.federation.core.wstrust.SamlCredential;
import org.picketlink.identity.federation.core.wstrust.WSTrustException;
import org.picketlink.identity.federation.core.wstrust.plugins.saml.SAMLUtil;
import org.w3c.dom.Element;

import edu.emory.cci.sts.client.CaGridSecurityTokenAttribute;

public class TestClient extends TestCase {

	// Testcase to check the issue token request

	public void testIssue() {

		// Specify username and password for the training account
		String username = "bogus1";
		String password = "pswd123456X$";

		try {
			// create a WSTrustClient instance.
			WSTrustClient client = new WSTrustClient(
					"PicketLinkSTS",
					"PicketLinkSTSPort",
					"https://secure01.cci.emory.edu:8443/EmorySTS/PicketLinkSTS",
					new SecurityInfo(username, password));

			// issue a SAML assertion using the client API.
			Element assertion = null;
			System.out
					.println("\nInvoking token service to get SAML assertion for "
							+ username);

			// specify the type of token you want to use. In this case its SAML2
			assertion = client.issueToken(SAMLUtil.SAML2_TOKEN_TYPE);
			System.out.println("SAML assertion for " + username
					+ " successfully obtained!");
			SamlCredential credential = new SamlCredential(assertion);
			System.out.println("Token Issued : " + credential);
		} catch (WSTrustException wse) {
			System.out
					.println("Unable to issue assertion: " + wse.getMessage());
			wse.printStackTrace();
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void testIssueValidate() throws Exception {
		String username = "bogus1";
		String password = "pswd123456X$";

		// create a WSTrustClient instance for the client
		WSTrustClient client = new WSTrustClient("PicketLinkSTS",
				"PicketLinkSTSPort",
				"https://secure01.cci.emory.edu:8443/EmorySTS/PicketLinkSTS",
				new SecurityInfo(username, password));

		// create a WSTrustClient instance for the service that wants to
		// validate the token
		WSTrustClient service = new WSTrustClient("PicketLinkSTS",
				"PicketLinkSTSPort",
				"https://secure01.cci.emory.edu:8443/EmorySTS/PicketLinkSTS",
				new SecurityInfo("nadir", "Xcdee356!335jk"));

		// issue a SAML assertion using the client API.
		Element assertion = null;
		try {
			System.out
					.println("\nInvoking token service to get SAML assertion for "
							+ username);
			assertion = client.issueToken(SAMLUtil.SAML2_TOKEN_TYPE);
			System.out.println("SAML assertion for " + username
					+ " successfully obtained!");
		} catch (WSTrustException wse) {
			System.out
					.println("Unable to issue assertion: " + wse.getMessage());
			wse.printStackTrace();
			System.exit(1);
		}

		SamlCredential credential = new SamlCredential(assertion);
		System.out.println(credential);

		// validate the token using the service side WSClient api
		System.out.println("Server Validates "
				+ service.validateToken(assertion));

		// Parse the token to extract proper fields
		CaGridSecurityTokenAttribute tokenAttributes = CaGridSecurityTokenAttribute
				.getCaGridSecurityTokenAttribute(credential
						.getAssertionAsString());

		System.out.println("Subject[" + tokenAttributes.getSubject() + "]");
		System.out.println("Dorian[" + tokenAttributes.getDorianUrl() + "]");
		System.out.println("GridGrouper[" + tokenAttributes.getGridGrouperUrl()
				+ "]");
		System.out.println("Groups[" + tokenAttributes.getGroupMembership()
				+ "]");
		System.out.println("GridCredential[" + tokenAttributes.getCredential()
				+ "]");

	}

}
