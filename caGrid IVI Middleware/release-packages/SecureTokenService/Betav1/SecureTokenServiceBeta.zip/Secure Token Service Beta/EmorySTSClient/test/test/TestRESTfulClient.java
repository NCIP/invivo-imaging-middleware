package test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.picketlink.identity.federation.core.util.Base64;

import junit.framework.TestCase;

public class TestRESTfulClient extends TestCase{

 
	public void testRESTfulClientIssueToken() throws Exception
	{
		String username= "bogus1";
		String password = "pswd123456X$";
		String stsUrl = "https://secure01.cci.emory.edu:8443/EmorySTS/PicketLinkSTS";
		
		HttpPost postRequest = new HttpPost("https://secure01.cci.emory.edu:8443/EmoryConceptSTSRESTfulAPI/rest/EmoryConceptSTSREST/IssueToken");
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("username", username));
		formparams.add(new BasicNameValuePair("password", password));
		formparams.add(new BasicNameValuePair("stsUrl", stsUrl));
		
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, "UTF-8");
		postRequest.setEntity(entity);
		HttpClient httpClient  = new DefaultHttpClient();
		HttpResponse response = httpClient.execute(postRequest);
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		HttpEntity responseEntity = response.getEntity();
		responseEntity.writeTo(bos);
	
		System.out.println(new String(bos.toByteArray()));
		
		
	 
	}
	
	public void testRESTfulClientIssueValidateToken() throws Exception
	{
		 // RESTful call to obtain the token
		String username= "bogus1";
		String password = "pswd123456X$";
		String stsUrl = "https://secure01.cci.emory.edu:8443/EmorySTS/PicketLinkSTS";
		
		HttpPost postRequest = new HttpPost("https://secure01.cci.emory.edu:8443/EmoryConceptSTSRESTfulAPI/rest/EmoryConceptSTSREST/IssueToken");
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("username", username));
		formparams.add(new BasicNameValuePair("password", password));
		formparams.add(new BasicNameValuePair("stsUrl", stsUrl));
		
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, "UTF-8");
		postRequest.setEntity(entity);
		HttpClient httpClient  = new DefaultHttpClient();
		HttpResponse response = httpClient.execute(postRequest);
		
		HttpEntity responseEntity = response.getEntity();
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		responseEntity.writeTo(bos);
		System.out.println(new String(bos.toByteArray()));
		
		
		
		// RESTful call to validate the token
		
		String validatorUsername= "nadir";
		String validatorPassword = "Xcdee356!335jk";
		postRequest = new HttpPost("https://secure01.cci.emory.edu:8443/EmoryConceptSTSRESTfulAPI/rest/EmoryConceptSTSREST/ValidateToken");
		formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("username", validatorUsername));
		formparams.add(new BasicNameValuePair("password", validatorPassword));
		formparams.add(new BasicNameValuePair("stsUrl", stsUrl));
		formparams.add(new BasicNameValuePair("assertion", new String(bos.toByteArray())));
		entity = new UrlEncodedFormEntity(formparams, "UTF-8");
		postRequest.setEntity(entity);
		httpClient  = new DefaultHttpClient();
		response = httpClient.execute(postRequest);
		
		responseEntity = response.getEntity();
		bos = new ByteArrayOutputStream();
		responseEntity.writeTo(bos);
		System.out.println("Token validated:\n" + new String(bos.toByteArray()));
	 
	}
	
	
}
