# The stsClient should be run by using the following ssl properties :

-Djavax.net.ssl.trustStore=certificates/stsClient.jks
-Djavax.net.ssl.trustStorePassword=yearkiwi

