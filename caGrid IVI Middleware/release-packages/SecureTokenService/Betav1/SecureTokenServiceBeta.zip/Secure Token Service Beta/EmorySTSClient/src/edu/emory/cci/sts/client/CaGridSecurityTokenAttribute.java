package edu.emory.cci.sts.client;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import org.globus.gsi.GlobusCredential;
import org.picketlink.identity.federation.core.util.Base64;

public class CaGridSecurityTokenAttribute {

	private  List<String> groupMembership;
	private  String dorianUrl;
	private  String gridGrouperUrl;
	private  GlobusCredential credential;
	private  String subject;
	
	
	public static CaGridSecurityTokenAttribute getCaGridSecurityTokenAttribute(String xmlToken ) throws Exception 
	{
		TokenParser parser = new TokenParser(xmlToken);
		CaGridSecurityTokenAttribute retVal = new CaGridSecurityTokenAttribute();
		Map<String,List<String>> attrs = parser.getTokenAttributes();
		
		retVal.groupMembership = attrs.get("groupMembership");
		retVal.dorianUrl = attrs.get("targetGrid").get(0);
		retVal.gridGrouperUrl = attrs.get("gridGrouper").get(0);
		retVal.subject = parser.getSubject();
				
		String encodedCert = attrs.get("GlobusCredential").get(0);
		byte[] bytes  = Base64.decode(encodedCert);
		ByteArrayInputStream stream = new ByteArrayInputStream(bytes);
		
		retVal.credential = new GlobusCredential(stream);
		stream.close();	
		return retVal;
		
	}
	public List<String> getGroupMembership() {
		return groupMembership;
	}
	public void setGroupMembership(List<String> groupMembership) {
		this.groupMembership = groupMembership;
	}
	public String getDorianUrl() {
		return dorianUrl;
	}
	public void setDorianUrl(String dorianUrl) {
		this.dorianUrl = dorianUrl;
	}
	public String getGridGrouperUrl() {
		return gridGrouperUrl;
	}
	public void setGridGrouperUrl(String gridGrouperUrl) {
		this.gridGrouperUrl = gridGrouperUrl;
	}
	public GlobusCredential getCredential() {
		return credential;
	}
	public void setCredential(GlobusCredential credential) {
		this.credential = credential;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String toString()
	{
		return "Subject[" + subject + "]\nGroups[" + groupMembership + "]\nDorian[" + dorianUrl + "]\nGridGrouer[" + gridGrouperUrl + "]\nGlobusCredential[" + credential + "]" ;
	}
	
}
