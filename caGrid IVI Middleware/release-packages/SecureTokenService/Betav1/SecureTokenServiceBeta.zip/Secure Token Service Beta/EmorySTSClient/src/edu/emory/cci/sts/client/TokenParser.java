package edu.emory.cci.sts.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

public class TokenParser {

	private JSONObject json ;
	
	public TokenParser(String xmlString) throws JSONException
	{
		 json = XML.toJSONObject(xmlString);
	}
	
	public String getSubject() throws JSONException
	{
		return json.getJSONObject("Assertion").getJSONObject("Subject").getJSONObject("NameID").getString("content");
	}
		 
	public  Map<String,List<String>> getTokenAttributes() throws JSONException
	{
		Map<String,List<String>> retVal = new HashMap<String, List<String>>();
		
		
		JSONObject attributeStatement = json.getJSONObject("Assertion").getJSONObject("AttributeStatement");
		JSONArray attributes = attributeStatement.getJSONArray("Attribute");
		
		for(int i=0 ;i< attributes.length() ; i++)
		{
			JSONObject attribute = attributes.getJSONObject(i);
			String attrName  = attribute.getString("Name");
			List<String> listOfValues = new ArrayList<String>();
			retVal.put(attrName, listOfValues);
			
			if(attribute.has("AttributeValue") == false) continue;
			
			Object obj = attribute.get("AttributeValue");
			
			if(obj instanceof JSONObject)
			{
				JSONObject jsonObj = (JSONObject) obj;
				String value = jsonObj.getString("content");
				listOfValues.add(value);
			}
			else if (obj instanceof JSONArray)
			{
				JSONArray arr = (JSONArray) obj;
				
				for(int j = 0 ; j< arr.length() ; j++)
				{
					JSONObject jsonObj = arr.getJSONObject(j);
					String value = jsonObj.getString("content");
					listOfValues.add(value);
				}
				
			}
			
			
		}
		
		return retVal;
	}
	
}
