package edu.emory.cci.sts.auth.ldap;

public interface NameBuilder {

	public String getName(String name);
}
