package edu.emory.cci.sts.auth;

import java.io.IOException;
import java.security.Principal;
import java.security.acl.Group;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.security.SimpleGroup;
import org.jboss.security.auth.spi.AbstractServerLoginModule;

import edu.emory.cci.sts.auth.ldap.NameBuilder;

public class LDAPLoginModule extends AbstractServerLoginModule {

	private String ldapServer;
	private Principal identity;
	private String defaultRole = "STSClient";
	private String username;
	private Log log = LogFactory.getLog(getClass());
	private Group defaultRoleGroup;
	private NameBuilder nameBuilder;

	public void initRoles() throws Exception {
		log.info("Initializing Default Role");
		Principal roleIdentity = createIdentity(defaultRole);
		defaultRoleGroup = new SimpleGroup("Roles");
		defaultRoleGroup.addMember(roleIdentity);

	}

	@Override
	protected Principal getIdentity() {

		return identity;
	}

	@Override
	protected Group[] getRoleSets() throws LoginException {
		log.info("Request for getting Groups [" + username + "]");
		return new Group[] { defaultRoleGroup };

	}

	@Override
	public void initialize(Subject subject, CallbackHandler callbackHandlers,
			Map<String, ?> sharedState, Map<String, ?> options) {

		super.initialize(subject, callbackHandlers, options, sharedState);

		try {
			ldapServer = (String) options.get("ldapServer");
			if (options.get("cnNameBuilder") != null) {
				String nameBuilderClass = (String) options.get("cnNameBuilder");
				nameBuilder = (NameBuilder) Class.forName(nameBuilderClass)
						.newInstance();
			}
			initRoles();
			log.info("DorianLoginModuleInitialized");

		} catch (Exception e) {

			log.error("Failed to initialize roles");
		}

	}

	@Override
	public boolean login() throws LoginException {
		try {
			log.info("Starting the login process");
			if (ldapServer == null)
				throw new LoginException("LDAP server not specified");

			if (nameBuilder == null)
				throw new LoginException("NameBuilder class not specified");

			String[] userPass = getUsernameAndPassword();
			boolean authStatus = authLDAP(userPass[0], userPass[1]);

			if (authStatus == true) {
				username = userPass[0];
				Principal principal = createIdentity(username);
				identity = new PrincipalWithAttributes(principal);
				log.info("Login successful with user identity [" + identity
						+ "]");
				loginOk = true;

				return true;
			} else {
				return false;
			}

		} catch (IOException e) {
			log.error(e);
			throw new LoginException(e.getMessage());
		} catch (UnsupportedCallbackException e) {
			log.error(e);
			throw new LoginException(e.getMessage());

		} catch (Exception e) {
			log.error(e);
			throw new LoginException(e.getMessage());
		}

	}

	public String[] getUsernameAndPassword() throws IOException,
			UnsupportedCallbackException {

		NameCallback nameCallback = new NameCallback("Username:");
		PasswordCallback passCallback = new PasswordCallback("Password", false);

		callbackHandler.handle(new Callback[] { nameCallback, passCallback });
		String[] retVal = new String[2];
		retVal[0] = nameCallback.getName();
		retVal[1] = new String(passCallback.getPassword());
		return retVal;
	}

	public boolean authLDAP(String username, String password) {

		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY,
				"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, ldapServer);
		env.put(Context.SECURITY_PRINCIPAL, nameBuilder.getName(username));
		env.put(Context.SECURITY_CREDENTIALS, password);

		try {
			DirContext ctx = new InitialDirContext(env);
		} catch (NamingException e) {
			log.error(e);
			return false;
		}

		return true;
	}

}
