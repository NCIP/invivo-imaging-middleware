package edu.emory.cci.sts.auth.ldap;

public class CCILDAPNameBuilder implements NameBuilder{

	private String template = "uid=<USERNAME>,ou=People,dc=cci,dc=emory,dc=edu" ;
	
	@Override
	public String getName(String name) {
		
		return template.replace("<USERNAME>", name);
	}

	
}
