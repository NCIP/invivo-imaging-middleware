package edu.emory.cci.sts.auth;

import edu.internet2.middleware.grouper.GrouperRuntimeException;
import edu.internet2.middleware.grouper.InsufficientPrivilegeException;

import gov.nih.nci.cagrid.dorian.client.IFSUserClient;
import gov.nih.nci.cagrid.gridgrouper.client.GridGrouper;
import gov.nih.nci.cagrid.gridgrouper.grouper.GroupI;
import gov.nih.nci.cagrid.opensaml.SAMLAssertion;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.security.auth.Subject;

import org.apache.axis.types.URI.MalformedURIException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.globus.gsi.GlobusCredential;
import org.jboss.security.SecurityContextAssociation;
import org.picketlink.identity.federation.core.util.Base64;
import org.picketlink.identity.federation.core.wstrust.plugins.saml.SAML20TokenAttributeProvider;
import org.picketlink.identity.federation.saml.v2.assertion.AttributeStatementType;
import org.picketlink.identity.federation.saml.v2.assertion.AttributeType;

public class GridGrouperSAMLAttributeProvider implements SAML20TokenAttributeProvider {

	private Log log = LogFactory.getLog(getClass());
	private GridGrouper grouper;
	private static String GRID_GROUPER_PROPERTY_NAME="gridGrouperUrl";
	private static String GROUP_MEMBERSHIP_PROPERTY_NAME="groupMembership";


	
	@Override
	public AttributeStatementType getAttributeStatement() {
		 Subject subject = SecurityContextAssociation.getSecurityContext().getSubjectInfo().getAuthenticatedSubject();
	      if( subject == null )
	      {
	             log.warn("No authentication Subject found, cannot provide any group information");
	             return createErrorAttributeStatement("Error retrieving group information");
	      }
	      else
	      {
	          AttributeStatementType attributeStatement = new AttributeStatementType();
	          
	          AttributeType targetGrid = new AttributeType();
	          targetGrid.setName("targetGrid");
	          
	          
	          AttributeType gridGrp = new AttributeType();
	          gridGrp.setName("gridGrouper");
	          gridGrp.getAttributeValue().add(grouper == null ? "not set" : grouper.getName());
	          
	          
	          
	          
	          AttributeType groupMembershipAttribute = new AttributeType();
	          groupMembershipAttribute.setName(GROUP_MEMBERSHIP_PROPERTY_NAME);
	         
	          attributeStatement.getAttributeOrEncryptedAttribute().add(groupMembershipAttribute);
	          attributeStatement.getAttributeOrEncryptedAttribute().add(targetGrid);
	          attributeStatement.getAttributeOrEncryptedAttribute().add(gridGrp);
	          
	         
	          
	          try {
	        	  
	        	  Principal identity = subject.getPrincipals().iterator().next();
	        	  
//	        	  targetGrid.getAttributeValue().add(IdentityRepository.getInstance().getAttribute(identity.getName(), "targetGrid"));
//	        	  GlobusCredential credential =  (GlobusCredential) IdentityRepository.getInstance().getAttribute(identity.getName(), "globusCredential");
	        	
	        	  targetGrid.getAttributeValue().add(((PrincipalWithAttributes) identity).getAttribute("targetGrid"));
	        	  GlobusCredential credential =  ((PrincipalWithAttributes) identity).getAttribute("globusCredential");
		          List<String> groupMembers = getGroupMembershipInfo(credential) ;
				
				for(String groupMember : groupMembers)
				{
					groupMembershipAttribute.getAttributeValue().add(groupMember);
				}
				
				attributeStatement.getAttributeOrEncryptedAttribute().add(this.getGlobusCredentialSAMLAttribute(credential));
				
			} catch (GrouperRuntimeException e) {
				log.error(e);
				return createErrorAttributeStatement("Error retrieving group information");
			} catch (InsufficientPrivilegeException e) {
				log.error(e);
				return createErrorAttributeStatement("Error retrieving group information");
			} catch (MalformedURIException e) {
				log.error(e);
				return createErrorAttributeStatement("Error retrieving group information");
			} catch (RemoteException e) {
				log.error(e);
				return createErrorAttributeStatement("Error retrieving group information");
			}catch( Exception e)
			{
				log.error(e);
				e.printStackTrace();
				return createErrorAttributeStatement("Error retrieving group information");
			}finally{
				
			}
	     
	          return attributeStatement;
	      }
	}
	
	private AttributeType getGlobusCredentialSAMLAttribute(GlobusCredential credential) throws IOException
	{
		AttributeType credentialAttr = new AttributeType();
		credentialAttr.setName("GlobusCredential");
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		credential.save(os);
		os.close();
		byte[] rawBytes = os.toByteArray();
		String base64encoded = Base64.encodeBytes(rawBytes);
		credentialAttr.getAttributeValue().add(base64encoded);
		return credentialAttr;
	}
	
	


	public AttributeStatementType createErrorAttributeStatement(String message)
	{
		AttributeStatementType attributeStatement = new AttributeStatementType();
        AttributeType errorAttribute = new AttributeType();
        errorAttribute.setName("error");
        errorAttribute.getAttributeValue().add(message);
        attributeStatement.getAttributeOrEncryptedAttribute().add(errorAttribute);
        return attributeStatement;
	}

	public  List<String> getGroupMembershipInfo(GlobusCredential credential ) throws GrouperRuntimeException, InsufficientPrivilegeException
	{
		List<String> list = new ArrayList<String>();
		Set<GroupI> set = grouper.getMembersGroups(credential.getIdentity());
		for(GroupI group : set)
		{
			list.add(group.getName().replaceAll(":", "/"));
		}
		
		return list;
	}
	@Override
	public void setProperties(Map<String, String> props) {
		String gridGrouperUrl = props.get(GRID_GROUPER_PROPERTY_NAME);
		if(gridGrouperUrl!=null)
		{
			grouper = new GridGrouper(gridGrouperUrl);
		}
		
		
		
	}

}
