package edu.emory.cci.rest.sts;

import javax.ws.rs.FormParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import org.picketlink.identity.federation.api.wstrust.WSTrustClient;
import org.picketlink.identity.federation.api.wstrust.WSTrustClient.SecurityInfo;
import org.picketlink.identity.federation.core.exceptions.ParsingException;
import org.picketlink.identity.federation.core.util.Base64;
import org.picketlink.identity.federation.core.wstrust.SamlCredential;
import org.picketlink.identity.federation.core.wstrust.plugins.saml.SAMLUtil;
import org.w3c.dom.Element;


@javax.ws.rs.Path("EmoryConceptSTSREST")
public class EmoryConceptSTSREST extends javax.ws.rs.core.Application{

	private String stsName;
	private String stsPort;
	
	
	
	public void init()
	{
		stsName = "PicketLinkSTS";
		stsPort = "PicketLinkSTSPort";
	}
	
	
	public EmoryConceptSTSREST()
	{
		init();
	}
	
	@javax.ws.rs.POST
	@javax.ws.rs.Path("IssueToken")
	@javax.ws.rs.Produces("text/xml")
	public String issueToken(@FormParam("username") String username , @FormParam("password") String password,@FormParam("stsUrl") String stsUrl) throws  Exception
	{
	
		System.out.println("Username:" + username + " password " + password + " stsUrl[" + stsUrl + "]");
		if( username == null) throw new Exception("Username field cannot be null");
		if( password == null) throw new Exception("Password field cannot be null");
		if( stsUrl == null) throw new Exception("stsUrl field cannot be null");
		
		WSTrustClient client = new WSTrustClient(stsName, stsPort, 
		            stsUrl, 
		            new SecurityInfo(username, password));
		
		Element assertion = client.issueToken(SAMLUtil.SAML2_TOKEN_TYPE);
		SamlCredential credential = new SamlCredential(assertion);
	    System.out.println(credential);
		return credential.getAssertionAsString();
	}
	
	
	
	
	
	
	
	
	
	
	
	@javax.ws.rs.POST
	@javax.ws.rs.Path("ValidateToken")
	public String validateToken(@FormParam("username") String username , @FormParam("password") String password,@FormParam("assertion") String assertion,@FormParam("stsUrl") String stsUrl) throws Exception
	{
		System.out.println("Username[" + username + "] password[" + password + "] assertion[" + assertion + "]" + " stsUrl[" + stsUrl + "]");
		
		if( username == null) throw new Exception("Username field cannot be null");
		if( password == null) throw new Exception("Password field cannot be null");
		if( stsUrl == null) throw new Exception("stsUrl field cannot be null");
		WSTrustClient client = new WSTrustClient(stsName, stsPort, 
		            stsUrl, 
		            new SecurityInfo(username, password));
		
		
		SamlCredential credential = new SamlCredential(assertion);
	    boolean retVal = client.validateToken(credential.getAssertionAsElement());
		return retVal + "" ;
	}
	
}
