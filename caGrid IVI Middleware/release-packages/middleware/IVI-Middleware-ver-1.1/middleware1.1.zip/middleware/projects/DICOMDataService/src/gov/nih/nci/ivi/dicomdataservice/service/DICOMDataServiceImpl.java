package gov.nih.nci.ivi.dicomdataservice.service;

import java.rmi.RemoteException;
import java.util.NoSuchElementException;
import java.util.Properties;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;

import org.apache.axis.MessageContext;
import org.apache.axis.types.Duration;
import org.apache.axis.types.URI;
import org.globus.ws.enumeration.ClientEnumIterator;
import org.globus.ws.enumeration.IterationConstraints;
import org.globus.wsrf.encoding.ObjectDeserializer;
import org.globus.wsrf.encoding.ObjectSerializer;
import org.globus.wsrf.encoding.SerializationException;
import org.xmlsoap.schemas.ws._2004._09.enumeration.EnumerateResponse;
import org.xmlsoap.schemas.ws._2004._09.enumeration.EnumerationContextType;

import gov.nih.nci.ivi.dicomdataservice.bdt.client.DICOMDataServiceBulkDataHandlerClient;
import gov.nih.nci.ivi.dicomdataservice.client.DICOMDataServiceClient;
import gov.nih.nci.ivi.dicomdataservice.submission.SubmissionInformation;
import gov.nih.nci.ivi.dicomdataservice.submit.client.DICOMDataServiceSubmitClient;
import gov.nih.nci.ivi.dicomdataservice.submit.stubs.types.DICOMDataServiceSubmitReference;

import gov.nih.nci.ivi.dicom.embeddedpacs.EmbeddedPACS;
import gov.nih.nci.ivi.dicomdataservice.submit.service.globus.resource.BaseResource;
import gov.nih.nci.ivi.dicomdataservice.submit.service.globus.resource.BaseResourceHome;
import gov.nih.nci.ivi.utils.ClientSecurityUtil;
import gov.nih.nci.ivi.utils.GridFTPFetcher;

/** 
 * DICOM data service with retrieve and submit functionality. DICOM data can be retrieved from an underlying DICOM database
 * through two different mechanisms: 1) As bulk data using GridFTP, or 2) In small chunks using Web service enumeration.
 * Also, local DICOM data can be uploaded to a DICOM database using submit method defined in this service.
 *
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class DICOMDataServiceImpl extends DICOMDataServiceImplBase {
/*
        private String serverip;
        private String serverport;
        private String serverAE;
        private String clientAE;
        private String tempdir;
        private String[] transportMechanisms;
        private String gftpserverurl;

        private ServiceConfiguration configuration;
*/        private EmbeddedPACS epacs = null;
	
	public DICOMDataServiceImpl() throws RemoteException {
		super();
        System.out.println("DICOMDataServiceImpl: init");
        boolean useCMOVE = false;
		try {
			String useCMOVEs = ServiceConfiguration.getConfiguration().getCqlQueryProcessorConfig_useCMOVE();
			if(useCMOVEs.equals("true"))
				useCMOVE = true;
			else
				useCMOVE = false;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RemoteException("Property useCMOVE was not property configured");
		}
        if (useCMOVE) {
            String username = System.getenv("LOGNAME");
            if (username == null) {
                username = "";
            }
            else {
                username = "-" + username;
            }
            String tmpdir = System.getProperty("java.io.tmpdir");
            System.out.println("tmpdir is " + tmpdir);
            String dumpdir =
                (tmpdir +
                 java.io.File.separator + "DICOMCQLQueryProcessor-embedded"
                 +username);
            System.out.println("dumpdir " + dumpdir);
            if (!new java.io.File(dumpdir).exists()) {
                System.out.println("making dump dir " + dumpdir);
                java.io.File f;

                f = new java.io.File(dumpdir);
                f.mkdir();
                assert(f.exists());

                f =new java.io.File((dumpdir + java.io.File.separator + "db"));
                f.mkdir();
                assert(f.exists());
            }

            try {
                System.out.println("starting embedded pacs...");
                Properties prop = gov.nih.nci.cagrid.data.service.ServiceConfigUtil.getQueryProcessorConfigurationParameters();
                this.epacs = new EmbeddedPACS(dumpdir, prop);
                this.epacs.start();
            }
            catch (Exception ex) {
                ex.printStackTrace();
                this.epacs.stop();
                throw new RemoteException("starting embedded pacs");
            }

        }
	}
	
	/** 
	 * This method returns an EPR to a BDT resource. This EPR can later be used to access the set of URLs,
	 * from which the DICOM data is going to be retrieved through gridFTP. Each URL contains a single zip file.
	 * After retrieval the zip files should be extracted. The following is a sample code fragment that illustrate
	 * the DICOM data retrieval from the DICOM data service using gridFTP.
	 * 
	 * <pre>
	 * DICOMDataServiceClient client = new DICOMDataServiceClient("http://127.0.0.1:8080/wsrf/services/cagrid/DICOMDataService");
	 * DICOMDataServiceBulkDataHandlerClient eprForRetrieval = dicomclient.retrieveWithGridFTP(cqlQuery);
	 * org.apache.axis.types.URI[] gridFtpUrls = eprForRetrieval.getGridFTPURLs();
	 * GridFTPFetcher gftpfetcher = new GridFTPFetcher();
	 * for (int i = 0; i < gridFtpUrls.length; i++) {
	 *    String url = gridFtpUrls[i].toString();
	 *    gftpfetcher.fetch(url, localFileName, true); //retrieve the zipped DICOM data file
	 *    // process the zip file retrieved to localFileName here
	 * }
	 * </pre>
	 * 
	 * @param cqlQuery The CQL query for filtering the requested DICOM data to be retrieved
	 * @return An end point reference for the Bulk Data Handler
	 *
	 */
	public gov.nih.nci.ivi.dicomdataservice.bdt.stubs.types.DICOMDataServiceBulkDataHandlerReference retrieveWithGridFTP(gov.nih.nci.cagrid.cqlquery.CQLQuery cQLQuery) throws RemoteException {
		org.apache.axis.message.addressing.EndpointReferenceType epr = new org.apache.axis.message.addressing.EndpointReferenceType();
		gov.nih.nci.cagrid.bdt.service.globus.resource.BaseResourceHome bdtHome = null;
		org.globus.wsrf.ResourceKey bdtResourceKey = null;
		org.apache.axis.MessageContext ctx = org.apache.axis.MessageContext.getCurrentContext();
		String servicePath = ctx.getTargetService();
		String bdtHomeName = org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME + servicePath + "/" + "dICOMDataServiceBulkDataHandlerHome";

		try {
			javax.naming.Context initialContext = new javax.naming.InitialContext();
			bdtHome = (gov.nih.nci.cagrid.bdt.service.globus.resource.BaseResourceHome) initialContext.lookup(bdtHomeName);
			bdtResourceKey = bdtHome.createBDTResource();
			
			//  Grab my newly created resource and set whatever needs to be set on it now
			BDTResource thisResource = (BDTResource)bdtHome.find(bdtResourceKey);
			//  This is where the creator of this resource type can set whatever needs
			//  to be set on the resource so that it can function appropriatly  for instance
			//  if you want the resouce to only have the query string then there is where you would
			//  give it the query string.
			
			// Let's run the query on this new resource
			
			System.out.println("Starting BDT WORK");
			String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
			thisResource.setParentURL(transportURL);
			thisResource.setIsWSEnum(false);
			thisResource.performRetrieveForGridFTP(cQLQuery);

			transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
			transportURL += "DICOMDataServiceBulkDataHandler";
			epr = org.globus.wsrf.utils.AddressingUtils.createEndpointReference(transportURL,bdtResourceKey);
		} catch (Exception e) {
			throw new RemoteException("Error looking up BDT home:" + e.getMessage(), e);
		}

		//return the typed EPR
		gov.nih.nci.ivi.dicomdataservice.bdt.stubs.types.DICOMDataServiceBulkDataHandlerReference ref = new gov.nih.nci.ivi.dicomdataservice.bdt.stubs.types.DICOMDataServiceBulkDataHandlerReference();
		ref.setEndpointReference(epr);

		return ref;
	}

	/** 
	 * This method returns an EPR to a bulk data submission resource. This EPR can later be used to upload a set of DICOM data,
	 * to a set of URLs obtained from that resource. A single zip file containing DICOM data can be uploaded to a URL.
	 * The following is a sample code fragment that illustrate data submission to the DICOM data service.
	 * 
	 * <pre>
	 * DICOMDataServiceClient dicomclient = new DICOMDataServiceClient("http://127.0.0.1:8080/wsrf/services/cagrid/DICOMDataService");
	 * SubmissionInformation submissionInfo = new SubmissionInformation();
	 * submissionInfo.setFileType("null");
	 * DICOMDataServiceSubmitClient eprForSubmission = dicomClient.submit(submissionInfo);
	 * org.apache.axis.types.URI[] gridFtpUrls = eprForSubmission.getUploadURLs();
	 * GridFTPFetcher gftpPutter = new GridFTPFetcher();
	 * for (int i = 0; i < gridFtpUrls.length; i++)
	 *    gftpPutter.secureUpload(new URI(gridFtpUrls[i].toString()), localFileName);
	 * eprForSubmission.processURLs(gridFtpUrls);
	 * </pre>
	 * 
	 * @param submissionInformation Some information about the submission
	 * @return An end point reference for the data submission resource
	 *
	 */
	public gov.nih.nci.ivi.dicomdataservice.submit.stubs.types.DICOMDataServiceSubmitReference submit(gov.nih.nci.ivi.dicomdataservice.submission.SubmissionInformation submissionInformation) throws RemoteException {
		org.apache.axis.message.addressing.EndpointReferenceType epr = new org.apache.axis.message.addressing.EndpointReferenceType();
		BaseResourceHome submitHome = null;
		org.globus.wsrf.ResourceKey submitResourceKey = null;
		org.apache.axis.MessageContext ctx = org.apache.axis.MessageContext.getCurrentContext();
		String servicePath = ctx.getTargetService();
		String submitHomeName = org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME + servicePath + "/" + "dICOMDataServiceSubmitHome";

		try {
			javax.naming.Context initialContext = new javax.naming.InitialContext();
			submitHome = (BaseResourceHome) initialContext.lookup(submitHomeName);
			submitResourceKey = submitHome.createResource();
			
			//  Grab my newly created resource and set whatever needs to be set on it now
			BaseResource thisResource = (BaseResource)submitHome.find(submitResourceKey);
			//  This is where the creator of this resource type can set whatever needs
			//  to be set on the resource so that it can function appropriatly  for instance
			//  if you want the resouce to only have the query string then there is where you would
			//  give it the query string.
			
			// Let's run the query on this new resource
			
			System.out.println("Initializing Submission Resource");
			thisResource.setSubmissionInformation(submissionInformation);
			
			

			String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
			transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
			transportURL += "DICOMDataServiceSubmit";
			epr = org.globus.wsrf.utils.AddressingUtils.createEndpointReference(transportURL,submitResourceKey);
		} catch (Exception e) {
			throw new RemoteException("Error looking up DICOMDataServiceSubmit home:" + e.getMessage(), e);
		}

		//return the typed EPR
		DICOMDataServiceSubmitReference ref = new DICOMDataServiceSubmitReference();
		ref.setEndpointReference(epr);
		return ref;
	}

	/** 
	 * This method returns an EPR to a BDT resource. This EPR can later be used to start an enumeration
	 * over the DICOM data files that are created by the service. Each element in the numeration contains a single zip file.
	 * After retrieving each zip file it should be extracted. The following is a sample code fragment that illustrate
	 * the DICOM data retrieval from the DICOM data service using Web service enumeration. Note that for better performance
	 * the retrieval process should be threaded.
	 * <pre>
	 * DICOMDataServiceClient dicomclient = new DICOMDataServiceClient("http://127.0.0.1:8080/wsrf/services/cagrid/DICOMDataService");
	 * DICOMDataServiceBulkDataHandlerClient epr = dicomclient.retrieveWithWSEnum(cqlQuery);
	 * EnumerateResponse enumerateResponse = epr.createEnumeration();
	 * EnumerationContextType enumerationContext = enumerateResponse.getEnumerationContext();
	 * ClientEnumIterator iterator = new ClientEnumIterator(epr, enumerationContext);
	 * QName qname = new QName("http://www.w3.org/2001/XMLSchema", "anyURI");
	 * boolean thereAreItems = true;
	 * GridFTPFetcher gftpfetcher = new GridFTPFetcher();
	 * while (thereAreItems) {
	 *    try {
	 *       while (iterator.hasNext()) {
	 *          SOAPElement element = (SOAPElement)iterator.next();
	 *          URI fileURI = (URI) ObjectDeserializer.toObject(element, URI.class);
	 *          String url = gridFtpUrls[i].toString();
	 *          gftpfetcher.fetch(url, localFileName, true); //retrieve the zipped DICOM data file
	 *          // process the zip file retrieved to localFileName here
	 *       }
	 *       thereAreItems = false;
	 *    } catch (NoSuchElementException e) {
	 *       thereAreItems = false;
	 *    }
	 * }
	 * </pre>
	 * 
	 * @param cqlQuery The CQL query for filtering the requested DICOM data to be retrieved
	 * @return An end point reference for the Bulk Data Handler
	 */
	public gov.nih.nci.ivi.dicomdataservice.bdt.stubs.types.DICOMDataServiceBulkDataHandlerReference retrieveWithWSEnum(gov.nih.nci.cagrid.cqlquery.CQLQuery cQLQuery) throws RemoteException {
		org.apache.axis.message.addressing.EndpointReferenceType epr = new org.apache.axis.message.addressing.EndpointReferenceType();
		gov.nih.nci.cagrid.bdt.service.globus.resource.BaseResourceHome bdtHome = null;
		org.globus.wsrf.ResourceKey bdtResourceKey = null;
		org.apache.axis.MessageContext ctx = org.apache.axis.MessageContext.getCurrentContext();
		String servicePath = ctx.getTargetService();
		String bdtHomeName = org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME + servicePath + "/" + "dICOMDataServiceBulkDataHandlerHome";

		try {
			javax.naming.Context initialContext = new javax.naming.InitialContext();
			bdtHome = (gov.nih.nci.cagrid.bdt.service.globus.resource.BaseResourceHome) initialContext.lookup(bdtHomeName);
			bdtResourceKey = bdtHome.createBDTResource();
			
			//  Grab my newly created resource and set whatever needs to be set on it now
			BDTResource thisResource = (BDTResource)bdtHome.find(bdtResourceKey);
			//  This is where the creator of this resource type can set whatever needs
			//  to be set on the resource so that it can function appropriatly  for instance
			//  if you want the resouce to only have the query string then there is where you would
			//  give it the query string.
			
			// Let's run the query on this new resource
			
			System.out.println("Starting BDT WORK");
			String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
			thisResource.setParentURL(transportURL);
			thisResource.setIsWSEnum(true);
			thisResource.performRetrieveForGridFTP(cQLQuery);

			transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
			transportURL += "DICOMDataServiceBulkDataHandler";
			epr = org.globus.wsrf.utils.AddressingUtils.createEndpointReference(transportURL,bdtResourceKey);
		} catch (Exception e) {
			throw new RemoteException("Error looking up BDT home:" + e.getMessage(), e);
		}

		//return the typed EPR
		gov.nih.nci.ivi.dicomdataservice.bdt.stubs.types.DICOMDataServiceBulkDataHandlerReference ref = new gov.nih.nci.ivi.dicomdataservice.bdt.stubs.types.DICOMDataServiceBulkDataHandlerReference();
		ref.setEndpointReference(epr);

		return ref;
	}

}

