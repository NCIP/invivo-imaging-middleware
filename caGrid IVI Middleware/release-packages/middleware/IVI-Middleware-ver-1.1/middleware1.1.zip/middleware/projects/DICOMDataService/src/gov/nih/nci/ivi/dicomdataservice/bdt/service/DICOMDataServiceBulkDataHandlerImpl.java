package gov.nih.nci.ivi.dicomdataservice.bdt.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class DICOMDataServiceBulkDataHandlerImpl extends DICOMDataServiceBulkDataHandlerImplBase {

	
	public DICOMDataServiceBulkDataHandlerImpl() throws RemoteException {
		super();
	}
	

}

