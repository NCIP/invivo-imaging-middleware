package gov.nih.nci.ivi.dicomdataservice.service;

import gov.nih.nci.cagrid.bdt.service.globus.resource.BDTException;
import gov.nih.nci.cagrid.bdt.service.globus.resource.BDTResourceBase;
import gov.nih.nci.cagrid.bdt.service.globus.resource.BDTResourceI;
import gov.nih.nci.cagrid.cqlquery.Association;
import gov.nih.nci.cagrid.cqlquery.CQLQuery;
import gov.nih.nci.cagrid.cqlquery.Group;
import gov.nih.nci.cagrid.cqlresultset.CQLQueryResults;
import gov.nih.nci.cagrid.data.MalformedQueryException;
import gov.nih.nci.cagrid.data.utilities.CQLQueryResultsIterator;
import gov.nih.nci.ivi.dicom.CQL2DICOM;
import gov.nih.nci.ivi.dicom.HashmapToCQLQuery;
import gov.nih.nci.ivi.dicom.PixelMedHelper;
import gov.nih.nci.ivi.dicom.modelmap.ModelMap;
import gov.nih.nci.ivi.dicom.modelmap.ModelMapException;
import gov.nih.nci.ivi.dicomdataservice.client.DICOMDataServiceClient;
import gov.nih.nci.ivi.utils.Zipper;
import gov.nih.nci.ncia.domain.GeneralSeries;
import gov.nih.nci.ncia.domain.Study;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Vector;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;

import org.apache.axis.types.URI.MalformedURIException;
import org.cagrid.authorization.callout.gridftp.db.DBUtil;
import org.cagrid.authorization.callout.gridftp.db.DatabaseException;
import org.cagrid.authorization.callout.gridftp.GridFTPTuple;
import org.cagrid.authorization.callout.gridftp.GridFTPOperation;
import org.globus.transfer.AnyXmlType;
import org.globus.ws.enumeration.EnumIterator;
import org.globus.ws.enumeration.IterationConstraints;
import org.globus.ws.enumeration.IterationResult;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.encoding.ObjectSerializer;
import org.globus.wsrf.encoding.SerializationException;

import com.pixelmed.dicom.Attribute;
import com.pixelmed.dicom.AttributeList;
import com.pixelmed.dicom.AttributeTag;
import com.pixelmed.dicom.CodeStringAttribute;
import com.pixelmed.dicom.DicomException;
import com.pixelmed.dicom.InformationEntity;
import com.pixelmed.dicom.TagFromName;
import com.pixelmed.network.DicomNetworkException;

/**
 * BDTResource is to represent the backend resource that will be persisted during this 
 * transfer of data to the callers. It is expected that the creator of this class will
 * implement at least the createEnumeration get methods and may add other mechanisms 
 * for transfer.
 */
public class BDTResource extends BDTResourceBase implements BDTResourceI {


	Vector <String> retrievedZipFileNames = null;
	private Thread t;
	private ModelMap map = null;
	private String parentURL = null;
	private Properties parentQueryProcessorProperties = null;
	private PixelMedHelper pixelMedHelper = null;

	private DBUtil util = null;
	private String port;
	private String host;

	private boolean gridFTPAuthorizationOn = false;
	private String connectionString = "jdbc:hsqldb:hsql://irondale.bmi.ohio-state.edu/" + "gridftp_authorization";
	private String dbuser = "sa";
	private String password = "ch3ck1t@uth";

//	private HashSet oldFileNames;
	private boolean isWSEnum = false;

	private boolean isRetrievalRequest = true;

	public BDTResource() {
		super();

		if (gridFTPAuthorizationOn) {

			try {
				util = new DBUtil(connectionString, dbuser, password);
				System.out.println("created the db connection");
			} catch (DatabaseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		try {
			port = ServiceConfiguration.getConfiguration().getGridFTPPort();
			host = ServiceConfiguration.getConfiguration().getGridFTPHost();
		} catch (Exception e) {
			System.err.println("GridFTP host or port was not configured properly");
		}

	}

	/**
	 * This method creates a WS-Enumeration EnumIterator  Once this Iterator is created
	 * the client will be able to use it to iterate through the results.
	 */
	public EnumIterator createEnumeration() throws BDTException {
		//oldFileNames = new HashSet();
		return new DICOMDataServiceEnumIterator();
	}

	/**
	 * This method returns the results as an XMLAnyType.  Essentially an XML blob.
	 */
	public AnyXmlType get() throws BDTException {
		//TODO: Implement me
		throw new BDTException("\"get()\" not yet implemented");
	}

	/**
	 * This method returns the results as a staged set of GridFTP URIs which can then be
	 * retieved using GridFTP client. Each URI points at a single zip file that contains
	 * some DICOM data.
	 * 
	 * @return The array of URIs pointing at the data to be retrieved from the service side
	 */
	public org.apache.axis.types.URI[] getGridFTPURLs() throws BDTException {

		String usr = org.globus.wsrf.security.SecurityManager.getManager().getCaller();
		System.out.println("getGridFTPURLS USER = " + usr);
		try {
			t.join();
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		org.apache.axis.types.URI[] out = new
		org.apache.axis.types.URI[retrievedZipFileNames.size()];

		try {
			for (int i = 0; i < retrievedZipFileNames.size(); i++)
			{
				// Let's make the URL.
				String ZippedFile = retrievedZipFileNames.get(i);
				if(ZippedFile == null)
					throw new BDTException("GridService could not retrieve data from PACS");
				String gridFTPUrl = "gsiftp://" + host + ":" + port + ZippedFile;
				System.out.println("url is " + gridFTPUrl);

				if (gridFTPAuthorizationOn) {
					// now add the authorization stuff
					String user = org.globus.wsrf.security.SecurityManager.getManager().getCaller();
					System.out.println("user is " + user);
					try {
						GridFTPOperation.Operation authOp = GridFTPOperation.Operation.READ;

						GridFTPTuple tuple = new GridFTPTuple(user, authOp, gridFTPUrl);
						util.insertTuple(tuple);
					} catch(MalformedURLException e) {
						//TODO do something
					}
				}

				out[i] = new org.apache.axis.types.URI(gridFTPUrl);
				System.out.println("Provided the URL at: " + System.currentTimeMillis());
			}
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}

		return out;

	}

	/**
	 * This method is internally used by the retrieveWithGridFTP method in {@link DICOMDataServiceImpl}.
	 */
	public void performRetrieveForGridFTP(CQLQuery cqlQuery)
	{
		parentQueryProcessorProperties = null;
		try {
			parentQueryProcessorProperties = gov.nih.nci.cagrid.data.service.ServiceConfigUtil.getQueryProcessorConfigurationParameters();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		System.out.println("model map file = " + String.class.cast(parentQueryProcessorProperties.get("modelMapProperties")));
		try {
			map = new ModelMap(String.class.cast(parentQueryProcessorProperties.get("modelMapProperties")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ModelMapException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		if(pixelMedHelper == null)
			pixelMedHelper = new PixelMedHelper(parentQueryProcessorProperties);

		try {
			final CQLQuery fcqlq = cqlQuery;
			t = new Thread(new dicomRetrieve(fcqlq));
			System.out.println("Started gridFTP retrieval at: " + System.currentTimeMillis());
			t.start();
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	class dicomRetrieve implements Runnable {
		private CQLQuery globalQuery;

		private Class seriesClass = null;
		private Class studyClass = null;

		public dicomRetrieve(CQLQuery cqlQuery) {
			globalQuery = cqlQuery;

			try {
				studyClass = map.getModelClassFromQueryRetrieveLevel(ModelMap.STUDY_STR);
				seriesClass = map.getModelClassFromQueryRetrieveLevel(ModelMap.SERIES_STR);
			} catch (ModelMapException e1) {
				e1.printStackTrace();
			}
		}

		public void run() {

			isRetrievalRequest = true;

			String dicomRetrieveTarget = globalQuery.getTarget().getName();
			final CQLQuery fcqlq = globalQuery;
			try {
				Class targetClass = Class.forName(dicomRetrieveTarget);
				InformationEntity ie = map.getInformationEntityFromModelClass(targetClass);
				String retrieveLevel = map.getRetrieveLevel(ie);
				if (retrieveLevel.equalsIgnoreCase(ModelMap.PATIENT_STR))
					retrievedZipFileNames = retrieveAtPatientLevel(fcqlq);
				else if (retrieveLevel.equalsIgnoreCase(ModelMap.STUDY_STR))
					retrievedZipFileNames = retrieveAtStudyLevel(fcqlq);
				else if (retrieveLevel.equalsIgnoreCase(ModelMap.SERIES_STR))
				{
					retrievedZipFileNames = new Vector<String>();
					retrievedZipFileNames.add(retrieveAtSeriesLevel(fcqlq));
				}
				else if (retrieveLevel.equalsIgnoreCase(ModelMap.IMAGE_STR))
				{	
					retrievedZipFileNames = new Vector<String>();
					retrievedZipFileNames.add(retrieveAtImageLevel(fcqlq));
				}
				else
					System.err.println("We should not be here - The retrieve level is: " + dicomRetrieveTarget);
			} catch (MalformedURIException e) {
				e.printStackTrace();
			} catch (RemoteException e) {
				e.printStackTrace();
			} catch (BDTException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				System.out.println("unable to get class for " + dicomRetrieveTarget + " " + e.getMessage());
			} catch (ModelMapException e) {
				System.out.println("unable to get query retrieve level for class " + dicomRetrieveTarget + e.getMessage());
			}
			if (retrievedZipFileNames == null) {
				retrievedZipFileNames = new Vector<String>();
				retrievedZipFileNames.add(null);        		
			}

			isRetrievalRequest = false;

		}

		private String retrieveAtImageLevel(CQLQuery queryImage) {

			String output = null;
			final CQLQuery newCqlQuery = modifyCQLQuery(queryImage);
			try {
				output = retrieveAtSeriesLevel(newCqlQuery);
			} catch (BDTException e) {
				e.printStackTrace();
			}

			return output;
		}

		private String retrieveAtSeriesLevel(CQLQuery querySeries) throws BDTException {

			String retrievedZipFile = null;
			try {
				CQL2DICOM cql2 = new CQL2DICOM(map);
				AttributeList filter = null;

				try {
					filter = cql2.cqlToPixelMed(querySeries);
					AttributeTag t = TagFromName.QueryRetrieveLevel;
					Attribute a = new CodeStringAttribute(t);
					// at this point, the retrievalDepth should already be set.
					InformationEntity queryRetrieveDepth = InformationEntity.SERIES;
					System.out.println("QueryRetrieveLevel: " + map.getRetrieveLevel(queryRetrieveDepth));
					a.addValue(map.getRetrieveLevel(queryRetrieveDepth));
					filter.put(t, a);

//					System.out.println(filter.toString());
					com.pixelmed.dicom.DicomDictionary dict = new com.pixelmed.dicom.DicomDictionary();
					System.out.println("dicom QR =\n" + filter.toString(dict)); 			
				} catch (DicomException e) {
					System.err.println("DICOM from CQL error: " + e.getLocalizedMessage());
				} catch (MalformedQueryException e) {
					e.printStackTrace();
				}

				String username = System.getenv("LOGNAME");
				if (username == null) {
					username = "";
				}
				else {
					username = "-" + username;
				}
				if(parentQueryProcessorProperties == null)
					throw new BDTException("BDT_Parent Query Processor cannot be accessed");


				pixelMedHelper.setIsWSEnum(getIsWSEnum());
				try {
					retrievedZipFile = pixelMedHelper.retrieveZippedCaching(
							filter,
							false,
							(System.getProperty("java.io.tmpdir") +
									File.separator + "DICOMCQLQueryProcessor-cache"
									+username));

				} catch (DicomNetworkException e) {
					e.printStackTrace();
				} catch (DicomException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

			} catch (ModelMapException e) {
				e.printStackTrace();
			}
			return retrievedZipFile;
		}

		private Vector<String> retrieveAtStudyLevel(CQLQuery queryStudy) throws MalformedURIException, RemoteException {


			Vector<String> output = new Vector<String>();

			final CQLQuery newCqlQuery = modifyCQLQuery(queryStudy);

			DICOMDataServiceClient ParentDicomClient = new DICOMDataServiceClient(parentURL);
			CQLQueryResults result = null;
			result = ParentDicomClient.query(newCqlQuery);

			CQLQueryResultsIterator iter2 = new CQLQueryResultsIterator(result);

			while (iter2.hasNext()) {
				//Object series = iter2.next();
				GeneralSeries series = GeneralSeries.class.cast(iter2.next());
				if (series == null) {
					System.out.println("something not right.  obj is null");
					continue;
				}
				//Object study = (seriesClass.cast(series).getStudy();
				Study study = series.getStudy();

				HashMap<String, String> retrieveQuery = null;
				HashmapToCQLQuery h2cql = new HashmapToCQLQuery(map);

				if (retrieveQuery == null || retrieveQuery.isEmpty()) {
					retrieveQuery = new HashMap<String, String>();
					retrieveQuery.put(HashmapToCQLQuery.TARGET_NAME_KEY, seriesClass.getCanonicalName());
					String seriesUIDTag = null;
					String studyUIDTag = null;
					try {
						seriesUIDTag = map.getDicomDict().getNameFromTag(map.getRetrieveLevelRequiredTag(ModelMap.SERIES_STR));
						studyUIDTag = map.getDicomDict().getNameFromTag(map.getRetrieveLevelRequiredTag(ModelMap.STUDY_STR));
						seriesUIDTag = "gov.nih.nci.ncia.domain.GeneralSeries.seriesInstanceUID";
						studyUIDTag = "gov.nih.nci.ncia.domain.Study.studyInstanceUID";
					} catch (ModelMapException e) {
						e.printStackTrace();
					}
					retrieveQuery.put(seriesUIDTag, series.getSeriesInstanceUID());
					retrieveQuery.put(studyUIDTag, study.getStudyInstanceUID());
					System.out.println("Hashmap is: " + HashmapToCQLQuery.TARGET_NAME_KEY + " + " + seriesClass.getCanonicalName());
					System.out.println("Hashmap is: " + seriesUIDTag + " + " + series.getSeriesInstanceUID());
					System.out.println("Hashmap is: " + studyUIDTag + " + " + study.getStudyInstanceUID());
				}

				try {
					final CQLQuery fcqlq = h2cql.makeCQLQuery(retrieveQuery);
					String retrievedSeries = retrieveAtSeriesLevel(fcqlq);
					output.add(retrievedSeries);
				} catch (MalformedQueryException e) {
					e.printStackTrace();
				} catch (BDTException e) {
					e.printStackTrace();
				}
			}

			if(output.size() != 0)
				//return zippedFiles.toArray(new String[zippedFiles.size()]);
				return output;
			else
				return null;
		}

		private Vector<String> retrieveAtPatientLevel(CQLQuery queryPatient) throws MalformedURIException, RemoteException {

			Vector<String> output = new Vector<String>();

			final CQLQuery newCqlQuery = modifyCQLQuery(queryPatient);

/*
			gov.nih.nci.cagrid.cqlquery.Object target = new gov.nih.nci.cagrid.cqlquery.Object();
			target.setName(seriesClass.getCanonicalName());
			queryPatient.setTarget(target);
*/
			DICOMDataServiceClient ParentDicomClient = new DICOMDataServiceClient(parentURL);

			CQLQueryResults result = null;
			result = ParentDicomClient.query(newCqlQuery);
			CQLQueryResultsIterator iter2 = new CQLQueryResultsIterator(result);

			while (iter2.hasNext()) {
				java.lang.Object obj = iter2.next();
				if (obj == null) {
					System.out.println("something not right.  obj is null");
					continue;
				}
				GeneralSeries series = GeneralSeries.class.cast(obj);
				Study study = series.getStudy();
				gov.nih.nci.ncia.domain.Patient patient = study.getPatient();

				HashMap<String, String> retrieveQuery = null;
				HashmapToCQLQuery h2cql = new HashmapToCQLQuery(map);

				if (retrieveQuery == null || retrieveQuery.isEmpty()) {
					retrieveQuery = new HashMap<String, String>();
					retrieveQuery.put(HashmapToCQLQuery.TARGET_NAME_KEY, seriesClass.getCanonicalName());
					retrieveQuery.put("gov.nih.nci.ncia.domain.GeneralSeries.seriesInstanceUID", series.getSeriesInstanceUID());
					retrieveQuery.put("gov.nih.nci.ncia.domain.Study.studyInstanceUID", study.getStudyInstanceUID());
				}

				try {
					System.out.println("WILL RETRIEVE FOR PATIENT: " + patient.getPatientId());
					CQLQuery cqlq = h2cql.makeCQLQuery(retrieveQuery);
					String retrievedSeries = this.retrieveAtSeriesLevel(cqlq);
					output.add(retrievedSeries);
				} catch (MalformedQueryException e) {
					e.printStackTrace();
				} catch (BDTException e) {
					e.printStackTrace();
				}
			}

			if(output.size() != 0)
				//return zippedFiles.toArray(new String[zippedFiles.size()]);
				return output;
			else
				return null;
		}


		private CQLQuery modifyCQLQuery(CQLQuery query2) {
			/*			System.out.println("The query BEFORE modifying the target is: ");
			try {
				System.err.println(ObjectSerializer.toString(query2,
						new QName("http://CQL.caBIG/1/gov.nih.nci.cagrid.CQLQuery", "CQLQuery")));
			} catch (SerializationException e) {
				e.printStackTrace();
			}
			 */
			gov.nih.nci.cagrid.cqlquery.Object target = query2.getTarget();

			gov.nih.nci.cagrid.cqlquery.Association assoc = target.getAssociation();
			gov.nih.nci.cagrid.cqlquery.Attribute attr = target.getAttribute();
			gov.nih.nci.cagrid.cqlquery.Group group = target.getGroup();

			HashMap <String, String> hcql = new HashMap <String, String>();

			if(group != null)
				hcql = handleGroups(group, target.getName());
			else if(assoc != null)
				hcql = handleAssoc(assoc);
			else if(attr != null)
				hcql = handleAttr(attr, target.getName());

			HashmapToCQLQuery h2cql = new HashmapToCQLQuery(map);
			Class targetClass = null;
			try {
				targetClass = map.getModelClassFromQueryRetrieveLevel(ModelMap.SERIES_STR);
			} catch (ModelMapException e1) {
				System.err.println("no matching model class for retrieve level " + ModelMap.SERIES_STR + " " + e1.getMessage());
				return null;
			}
			hcql.put(HashmapToCQLQuery.TARGET_NAME_KEY, targetClass.getCanonicalName());

			CQLQuery cqlq = null;
			try {
				cqlq = h2cql.makeCQLQuery(hcql);
			} catch (MalformedQueryException e) {
				e.printStackTrace();
			}

			/*			System.out.println("The query AFTER modifying the target is: ");
			try {
				System.err.println(ObjectSerializer.toString(cqlq,
						new QName("http://CQL.caBIG/1/gov.nih.nci.cagrid.CQLQuery", "CQLQuery")));
			} catch (SerializationException e) {
				e.printStackTrace();
			}
			 */
			return cqlq;
		}

		private HashMap<String, String> handleAttr(gov.nih.nci.cagrid.cqlquery.Attribute attr, String parentName) {
			HashMap <String, String> hcql = new HashMap <String, String>();
			String fullName = parentName + '.' + attr.getName();
			hcql.put(fullName, attr.getValue());
			System.out.println("NAME = " + attr.getName() + "  VALUE = " + attr.getValue());
			return hcql;
		}

		private HashMap<String, String> handleAssoc(Association assoc) {
			System.out.println("In handleASSOC");
			HashMap <String, String> hcql = new HashMap <String, String>();

			gov.nih.nci.cagrid.cqlquery.Association assoc2 = assoc.getAssociation();
			gov.nih.nci.cagrid.cqlquery.Attribute attr = assoc.getAttribute();
			gov.nih.nci.cagrid.cqlquery.Group group = assoc.getGroup();

			if(assoc2 != null)
				hcql.putAll(handleAssoc(assoc2));
			if(attr != null)
				hcql.putAll(handleAttr(attr, assoc.getName()));
			if(group != null)
				hcql.putAll(handleGroups(group, assoc.getName()));

			return hcql;
		}

		private HashMap<String, String> handleGroups(Group group, String parent) {
			System.out.println("In handleGROUP");
			HashMap <String, String> hcql = new HashMap <String, String>();

			gov.nih.nci.cagrid.cqlquery.Association[] assoc = group.getAssociation();
			gov.nih.nci.cagrid.cqlquery.Attribute[] attr = group.getAttribute();

			if(assoc != null)
				for(int i = 0; i < assoc.length ; i++)
					hcql.putAll(handleAssoc(assoc[i]));
			if(attr != null)
				for(int i = 0; i < attr.length ; i++)
					hcql.putAll(handleAttr(attr[i], parent));
			return hcql;
		}
	}


	/**
	 * This is the callback to destroy this resource. If anything needs to be cleaned up
	 * when this resource is destroyed it should be done here.
	 */
	public void remove() throws ResourceException {
		String usr = org.globus.wsrf.security.SecurityManager.getManager().getCaller();
		System.out.println("remove USER = " + usr);

		if (retrievedZipFileNames != null) {
			for (int i = 0; i < retrievedZipFileNames.size() ; i++) {
				File zippedFile = new File(retrievedZipFileNames.get(i));
				zippedFile.delete();

				if (gridFTPAuthorizationOn) {
					String gridFTPUrl = "gsitp://" + host + ":" + port + retrievedZipFileNames.get(i);
					System.out.println("url is " + gridFTPUrl);

					// now add the authorization stuff
					String user = org.globus.wsrf.security.SecurityManager.getManager().getCaller();
					try {
						GridFTPOperation.Operation authOp = GridFTPOperation.Operation.READ;
						GridFTPTuple tuple = new GridFTPTuple(user, authOp, gridFTPUrl);
						try {
							util.removeTuple(tuple);
						} catch (DatabaseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} catch(MalformedURLException e) {
						//TODO do something
					}
				}
			}
		}
	}

	public void setIsWSEnum(boolean isWSEnum) {
		this.isWSEnum = isWSEnum;
	}

	public boolean getIsWSEnum() {
		return isWSEnum;
	}

	public void setParentURL (String url)
	{
		parentURL = url;
		System.out.println("parent URL = " + parentURL);
	}

	public String getParentURL ()
	{
		return parentURL;
	}

	private class DICOMDataServiceEnumIterator implements EnumIterator {

		int URICount;

		DICOMDataServiceEnumIterator() {
			URICount = 0;
		}

		public IterationResult next(IterationConstraints constraints) {
//			System.out.println("next request issued");
			IterationResult iterationResult = null;
			Vector <String> allFileNames = null;
			boolean URIsAvailable = false;
			boolean iterationFlag = false;
			int numberOfAllFiles;
			int SLEEP_TIME = 50;
			
			boolean contextSwitchFlag = false;
			
			do {
				try {
					Thread.sleep(SLEEP_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(isRetrievalRequest == true)
				{
//					System.out.println("C_GET IS GOING ON");
					if(pixelMedHelper != null)
					{
						allFileNames = pixelMedHelper.getRetrievedFileNames();
						numberOfAllFiles = allFileNames.size();						
					}
					else
					{
						numberOfAllFiles = 0;
					}
					
					if (numberOfAllFiles > 0)
					{
//						for(int i = 0; i < numberOfAllFiles; i++)
//							System.out.println("ENUMERATOR: " + allFileNames.get(i));
						URIsAvailable = true;
					}
				}
				else
				{
/*
					System.out.println("C_GET IS OVER will sleep now");
					try {
						Thread.sleep(SLEEP_TIME);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
*/
					if(pixelMedHelper != null)
					{
						allFileNames = pixelMedHelper.getRetrievedFileNames();
						numberOfAllFiles = allFileNames.size();					
					}
					else
					{
						numberOfAllFiles = 0;
					}

					if(numberOfAllFiles == 0)
					{
						// no new data after NO new data condition?
//						System.out.println("There will not be any more data will destroy");
						iterationResult = new IterationResult(null, true);
						return iterationResult;
					}
					else //final chunk of data
					{
//						for(int i = 0; i < allFileNames.size(); i++)
//							System.out.println("ENUMERATOR: " + allFileNames.get(i));
						URIsAvailable = true;
					}
				}
				
				
			} while (!URIsAvailable);
			
//			System.out.println("started creating the results, " + numberOfAllFiles + " new files");
//			System.out.println("started creating the results, " + (numberOfAllFiles-oldFileNames.size()) + " new files");
			QName qname = new QName("http://www.w3.org/2001/XMLSchema", "anyURI");
			int fileCount = 0;
			boolean zipFiles = true;
			SOAPElement[] elements = null;
			if (zipFiles) {
//				String fileNames[] = new String[numberOfAllFiles-oldFileNames.size()];
				String fileNames[] = new String[numberOfAllFiles];
				for (int i = 0; i < numberOfAllFiles; i++) {
					String fileName = allFileNames.elementAt(i);
					fileNames[fileCount++] = new String(fileName);
/*					if (!oldFileNames.contains(fileName)) {
						// this file is newly created, so add it to the results
						System.out.println("new file found. adding result " + fileName);
						fileNames[fileCount] = new String(fileName);
						fileCount++;
						oldFileNames.add(fileName);
					}
*/				}
				String username = System.getenv("LOGNAME");
				if (username == null)
					username = "";
				else
					username = "-" + username;
				File tmpDir = new File(System.getProperty("java.io.tmpdir") + File.separator + "DICOMDataService-WSEnum" + username);
				tmpDir.mkdirs();
				String tmpFileName = null;
				try {
					tmpFileName = File.createTempFile("tmp", ".zip", tmpDir).getCanonicalPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					Zipper.zip(tmpFileName, fileNames, false);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				for (int i = 0; i < fileNames.length; i++)
					new File(fileNames[i]).delete();
				elements = new SOAPElement[1];
				try {
					elements[0] = ObjectSerializer.toSOAPElement("gsiftp://" + host + ":" + port + tmpFileName, qname);
				} catch (SerializationException e) {
					e.printStackTrace();
				}
				System.out.println("returning the created zip file " + tmpFileName);
			}
			else {
//				elements = new SOAPElement[numberOfAllFiles-oldFileNames.size()];
//				for (int i = 0; i < numberOfAllFiles; i++) {
//					String fileName = allFileNames.elementAt(i);
//					if (!oldFileNames.contains(fileName)) {
//						// this file is newly created, so add it to the results
//						try {
//							System.out.println("new file found. adding result " + fileName);
//							elements[fileCount] = ObjectSerializer.toSOAPElement("gsiftp://" + host + ":" + port + fileName, qname);
//							fileCount++;
//						} catch (SerializationException e) {
//							e.printStackTrace();
//						}
//						oldFileNames.add(fileName);
//					}
//				}
				System.out.println("returning " + fileCount + " individual files");
			}
			iterationResult = new IterationResult(elements, iterationFlag);
			return iterationResult;
		}

		public void release() {
		}

	}


}
